#include "local.h"

int main (int argc, char *argv[ ]){		
	if(argc != 2) {
		perror("Number of arguments must be 1 --> you must pass input file as argument !\n");
		exit(-1);
	}
	read_configuration(argv[1]); 
	parentPid =getpid();
	srand((unsigned) getpid());
	PatchKey=14500;
	Patch = msgget(PatchKey, 0666 | IPC_CREAT);
	
	printDateQueueKey=16500;
	printDateQueue = msgget(printDateQueueKey, 0666 | IPC_CREAT);
	
	typeALine1Key=10500;
	typeALine1 = msgget(typeALine1Key, 0666 | IPC_CREAT);
	
	typeALine2Key=9500;
	typeALine2 = msgget(typeALine2Key, 0666 | IPC_CREAT);
	
	typeALine3Key=7500;
	typeALine3 = msgget(typeALine3Key, 0666 | IPC_CREAT);
	
	typeBLine1Key=6500;
	typeBLine1 = msgget(typeBLine1Key, 0666 | IPC_CREAT);
	
	typeBLine2Key=5500;
	typeBLine2 = msgget(typeBLine2Key, 0666 | IPC_CREAT);
	
	typeCLine1Key=3500;
	typeCLine1 = msgget(typeCLine1Key, 0666 | IPC_CREAT);
	
	typeCLine2Key=1500;
	typeCLine2 = msgget(typeCLine2Key, 0666 | IPC_CREAT);
	
	printDateDoneKey=18500;
	printDateDone = msgget(printDateDoneKey, 0666 | IPC_CREAT);

	typeAContainerKey=20500;
	typeAContainer=msgget(typeAContainerKey, 0666 | IPC_CREAT);
	
	typeBContainerKey=22500;
	typeBContainer=msgget(typeBContainerKey, 0666 | IPC_CREAT);
	
	typeCContainerKey=24500;
	typeCContainer=msgget(typeCContainerKey, 0666 | IPC_CREAT);
	
	cartonBoxesKey=26500;
	cartonBoxes=msgget(cartonBoxesKey, 0666 | IPC_CREAT);
	
	storageAreaKey=28500;
	storageArea=msgget(storageAreaKey, 0666 | IPC_CREAT);
	
	truckKey=30500;
	truck=msgget(truckKey, 0666 | IPC_CREAT);
	clock_gettime(CLOCK_MONOTONIC, &start);
	forkOpenGl();
    
	for (int counterA=0; counterA <typeAmanfactorLines ;counterA++){
		pthread_create(&threadidTypeA[counterA], NULL,(void *) typeAThread,(void *) &counterA);
	}
	for (int counterB=0; counterB<typeBmanfactorLines ;counterB++){
		pthread_create(&threadidTypeB[counterB], NULL,(void *) typeBThread,(void *) &counterB);
	}
	for (int counterC=0; counterC<typeCmanfactureLines ;counterC++){
		pthread_create(&threadidTypeC[counterC], NULL,(void *) typeCThread,(void *) &counterC);
	}
	for (int patchCounter=0 ; patchCounter<patchEmployee; patchCounter++ ){
		pthread_create(&patchThreadid[patchCounter], NULL,(void *) patchThread,(void *) &patchCounter);
	}
	pthread_create(&printingExprestionDate, NULL,(void *) printingExprestionThread,(void *) &r2);
	
	for (int collectingTypeCounter=0 ; collectingTypeCounter<collectingTypeEmployee; collectingTypeCounter++ ){
		pthread_create(&collectingTypeid[collectingTypeCounter], NULL,(void *) collectingTypeThread ,(void *) &collectingTypeCounter);
	}
	for (int prepareAndFillCartonCounter=0 ; prepareAndFillCartonCounter<prepareAndFillCartonEmployees; prepareAndFillCartonCounter++ ){
		pthread_create(&prepareAndFillCartonId[prepareAndFillCartonCounter], NULL,(void *) prepareAndFillCarton ,(void *) &prepareAndFillCartonCounter);
	}
	for (int storageAreaCounter=0 ; storageAreaCounter<storageAreaEmployee; storageAreaCounter++ ){
		pthread_create(&storageAreaId[storageAreaCounter], NULL,(void *) storageAreaThread ,(void *) &storageAreaCounter);
	}
	for (int LoadingEmployeeCounter=0 ; LoadingEmployeeCounter<loadingEmployee ; LoadingEmployeeCounter++ ){
		pthread_create(& loadingEmployeeId[LoadingEmployeeCounter], NULL,(void *) loadingEmployeeThread ,(void *) &LoadingEmployeeCounter);
	}

    pthread_create(&thread_console, NULL, print_msg, NULL);
	
	pthread_create(& termination, NULL,(void *) terminationThread ,(void *) &r2);
	while(1){
		for (int truckCounter =0 ; truckCounter <truckNumber ; truckCounter++ ){
			pthread_create(&truckId[truckCounter], NULL,(void *) truckThread ,(void *) &truckCounter);
			pthread_join(truckId[truckCounter], NULL);
		}
	}

	for (int counterA=0; counterA<typeAmanfactorLines;counterA++){
		pthread_join(threadidTypeA[counterA], NULL);
	}
	for (int counterB=0; counterB<typeBmanfactorLines ;counterB++){
		pthread_join(threadidTypeB[counterB], NULL);
	}
	for (int counterC=0; counterC<typeCmanfactureLines ;counterC++){
		pthread_join(threadidTypeC[counterC], NULL);
	}
	for (int patchCounter=0 ; patchCounter<patchEmployee; patchCounter++ ){
		pthread_join(patchThreadid[patchCounter], NULL);
	}
		pthread_join(printingExprestionDate, NULL);	
		
	for (int collectingTypeCounter=0 ; collectingTypeCounter<collectingTypeEmployee; collectingTypeCounter++ ){
		pthread_join(collectingTypeid[collectingTypeCounter], NULL);
	}
	for (int prepareAndFillCartonCounter=0 ; prepareAndFillCartonCounter<prepareAndFillCartonEmployees; prepareAndFillCartonCounter++ ){
		pthread_join(prepareAndFillCartonId[prepareAndFillCartonCounter], NULL);
	}
	for (int storageAreaCounter=0 ; storageAreaCounter<storageAreaEmployee; storageAreaCounter++ ){
		pthread_join(storageAreaId[storageAreaCounter], NULL);
	}
	for (int LoadingEmployeeCounter=0 ; LoadingEmployeeCounter<loadingEmployee ; LoadingEmployeeCounter++ ){
		pthread_join(loadingEmployeeId[LoadingEmployeeCounter], NULL);
	}
		pthread_join( termination, NULL);
		pthread_join(thread_console, NULL);
}

void forkOpenGl( ){
	for (unsigned int i = 0 ; i < 1 ; i++) {
		if ((pid = fork()) == -1) {
			printf("\033[0;31m"); // set the color to red 
			printf("Fork failure !!");
			printf("\033[0m");// reset the color to the default       
			exit(-1);
		}else if (pid == 0){
			execlp("./openGl","./openGl",(char *)NULL);
		}else {
		
		}
	}
}

void terminationThread(){

	while(1){
		pthread_mutex_lock(&cartonTypeA_mutex);
		int cartonA=cartonTypeA;
		pthread_mutex_unlock(&cartonTypeA_mutex);
		pthread_mutex_lock(&cartonTypeB_mutex);
		int cartonB=cartonTypeB;
		pthread_mutex_unlock(&cartonTypeB_mutex);
		pthread_mutex_lock(&cartonTypeC_mutex);
		int cartonC=cartonTypeC;
		pthread_mutex_unlock(&cartonTypeC_mutex);
		double elapsed,finish_minutes,start_minutes;	
		clock_gettime(CLOCK_MONOTONIC, &finish);
		elapsed = (finish.tv_sec - start.tv_sec) ;
		elapsed += (finish.tv_nsec - start.tv_nsec) / 1000000000.0;
    			 
		if ((cartonA >=box_typeA && cartonB >=box_typeB && cartonC >= box_typeC) || ((elapsed/60) >= simulation_time ) ){
			// termination 
			printf("🥺😔 SORRY NO MORE CHOCOLATE 🥺😔\n");
			fflush(stdout);

			for (int counterA=0; counterA <typeAmanfactorLines ;counterA++){
				if (pthread_cancel(threadidTypeA[counterA]) != 0){
					perror("Failed to cancel manufacturing lines thread\n");
				}
			}
			for (int counterB=0; counterB<typeBmanfactorLines ;counterB++){
				if (pthread_cancel(threadidTypeB[counterB]) != 0){
					perror("Failed to cancel manufacturing lines thread\n");
				}
			}
			for (int counterC=0; counterC<typeCmanfactureLines ;counterC++){
				if (pthread_cancel(threadidTypeC[counterC]) != 0){
					perror("Failed to cancel manufacturing lines thread\n");
				}
			}
			for (int patchCounter=0 ; patchCounter<patchEmployee; patchCounter++ ){
				if (pthread_cancel(patchThreadid[patchCounter]) != 0){
					perror("Failed to cancel manufacturing lines thread\n");
				}
			}

			if (pthread_cancel(printingExprestionDate)!=0){
				perror("Failed to cancel manufacturing lines thread\n");
			}
			

			for (int collectingTypeCounter=0 ; collectingTypeCounter<collectingTypeEmployee; collectingTypeCounter++ ){
				if (pthread_cancel(collectingTypeid[collectingTypeCounter])!=0){
					perror("Failed to cancel manufacturing lines thread\n");
				}
			}
			for (int prepareAndFillCartonCounter=0 ; prepareAndFillCartonCounter<prepareAndFillCartonEmployees; prepareAndFillCartonCounter++ ){
				if (pthread_cancel(prepareAndFillCartonId[prepareAndFillCartonCounter])!=0){
					perror("Failed to cancel manufacturing lines thread\n");
				}
			}
			for (int storageAreaCounter=0 ; storageAreaCounter<storageAreaEmployee; storageAreaCounter++ ){
				if (pthread_cancel(storageAreaId[storageAreaCounter])!=0){
					perror("Failed to cancel manufacturing lines thread\n");
				}
			}
			for (int LoadingEmployeeCounter=0 ; LoadingEmployeeCounter<loadingEmployee ; LoadingEmployeeCounter++ ){
				if (pthread_cancel(loadingEmployeeId[LoadingEmployeeCounter])!=0){
					perror("Failed to cancel manufacturing lines thread\n");
				}
			}
			for (int i=1; i<=employeeANumbers; i++){
				pthread_cancel(threadTypeAEmployees[1][i]); 	
				pthread_cancel(threadTypeAEmployees[2][i]); 		
				pthread_cancel(threadTypeAEmployees[3][i]); 		
			}
			for (int i=1; i<=employeeBNumbers; i++){
				pthread_cancel(threadTypeBEmployees[1][i]); 
				pthread_cancel(threadTypeBEmployees[2][i]);

			}
			for (int i=1; i<=employeeCNumbers; i++){
				pthread_cancel(threadTypeCEmployees[1][i]); 
				pthread_cancel(threadTypeCEmployees[2][i]); 
			}
			for (int truckCounter =0 ; truckCounter <truckNumber ; truckCounter++ ){
				pthread_cancel(truckId[truckCounter]);
			}

			msgctl(Patch, IPC_RMID, NULL);
			msgctl(printDateQueue, IPC_RMID, NULL);
			msgctl(typeALine1, IPC_RMID, NULL);
			msgctl(typeALine2, IPC_RMID, NULL);
			msgctl(typeALine3, IPC_RMID, NULL);
			msgctl(typeBLine1, IPC_RMID, NULL);
			msgctl(typeBLine2, IPC_RMID, NULL);
			msgctl(typeCLine1, IPC_RMID, NULL);
			msgctl(typeCLine2, IPC_RMID, NULL);
			msgctl(printDateDone, IPC_RMID, NULL);
			msgctl(typeAContainer, IPC_RMID, NULL);
			msgctl(typeBContainer, IPC_RMID, NULL);
			msgctl(typeCContainer, IPC_RMID, NULL);
			msgctl(cartonBoxes, IPC_RMID, NULL);
			msgctl(storageArea, IPC_RMID, NULL);
			msgctl(truck, IPC_RMID, NULL);
			pthread_mutex_destroy(&typeALine1_mutex);
			pthread_mutex_destroy(&typeALine3_mutex);
			pthread_mutex_destroy(&typeALine2_mutex);
			pthread_mutex_destroy(&typeBLine1_mutex);
			pthread_mutex_destroy(&typeBLine2_mutex);
			pthread_mutex_destroy(&typeA_mutex);
			pthread_mutex_destroy(&typeB_mutex);
			pthread_mutex_destroy(&typeC_mutex);
			pthread_mutex_destroy(&flagA1_mutex);
			pthread_mutex_destroy(&flagA2_mutex);
			pthread_mutex_destroy(&flagA3_mutex);
			pthread_mutex_destroy(&timeA_mutex);
			pthread_mutex_destroy(&timeB_mutex);
			pthread_mutex_destroy(&flagC1_mutex);
			pthread_mutex_destroy(&flagC2_mutex);
			pthread_mutex_destroy(&patchCounter_mutex);
			pthread_mutex_destroy(&counterTypeA_mutex);
			pthread_mutex_destroy(&counterTypeB_mutex);
			pthread_mutex_destroy(&counterTypeC_mutex);
			pthread_mutex_destroy(&cartonTypeA_mutex);
			pthread_mutex_destroy(&cartonTypeB_mutex);
			pthread_mutex_destroy(&cartonTypeC_mutex);
			pthread_mutex_destroy(&carton_mutex);
			pthread_mutex_destroy(&pause_mutex);
			pthread_mutex_destroy(&counterATruck_mutex);
			pthread_mutex_destroy(&counterBTruck_mutex);
			pthread_mutex_destroy(&counterCTruck_mutex);
			pthread_cancel(termination);	
			kill(pid,SIGINT);
			kill(parentPid,SIGINT);
		}
		
	}

}


// Type A Line 
void typeAThread(int *line_number){
	pthread_t thread;
	thread=pthread_self();
	int line1=1;
	int line2=2;
	int line3=3;
	while(1){
		sleep(1);
		
		if (pthread_equal(thread,threadidTypeA[0])){
			for (int i=1; i<=employeeANumbers; i++){
				if (i >=1 && i<=4){
					pthread_create(&threadTypeAEmployees[1][i], NULL,(void *) inOrderEmployeeA1,(void *) &line1); // in order steps
				}else {
					pthread_create(&threadTypeAEmployees[1][i], NULL,(void *) inAnyOrderEmployeeA1,(void *) &line1); // in any order steps
				}
				sleep(4);		
			}
		}
		if (pthread_equal(thread,threadidTypeA[1])){
			for (int i=1; i<=employeeANumbers; i++){
				if (i >=1 && i<=4){
					pthread_create(&threadTypeAEmployees[2][i], NULL,(void *) inOrderEmployeeA2,(void *) &line2); // in order steps 
				}else {
					pthread_create(&threadTypeAEmployees[2][i], NULL,(void *) inAnyOrderEmployeeA2,(void *) &line2); // in any order steps
				}
				sleep(4);	
			}	
		}
		if (pthread_equal(thread,threadidTypeA[2])){
			for (int i=1; i<=employeeANumbers; i++){
				if (i >=1 && i<=4){
					pthread_create(&threadTypeAEmployees[3][i], NULL,(void *) inOrderEmployeeA3,(void *) &line3); // in order steps 
				}else {
					pthread_create(&threadTypeAEmployees[3][i], NULL,(void *) inAnyOrderEmployeeA3,(void *) &line3); // in any order steps
				}
				sleep(4);		
			}	
		}
		for (int i=1; i<=employeeANumbers; i++){
			pthread_join(threadTypeAEmployees[1][i], NULL);
			pthread_join(threadTypeAEmployees[2][i], NULL);
			pthread_join(threadTypeAEmployees[3][i], NULL);
		}
		
	}	
}

void *print_msg(void *data){

	unsigned int i;

    while (true)
    {
    	pthread_mutex_lock(&counterTypeA_mutex);
		
		int counterA=counterTypeA;
		pthread_mutex_unlock(&counterTypeA_mutex);
		
		pthread_mutex_lock(&counterTypeB_mutex);
		int counterB=counterTypeB;
		pthread_mutex_unlock(&counterTypeB_mutex);
		
		pthread_mutex_lock(&counterTypeC_mutex);
		int counterC=counterTypeC;
		pthread_mutex_unlock(&counterTypeC_mutex);
		pthread_mutex_lock(&patchCounter_mutex);
		int patchCounter=patch_counter;
		pthread_mutex_unlock(&patchCounter_mutex);
		pthread_mutex_lock(&carton_mutex);
		int cartonN=cartonNumber;
		pthread_mutex_unlock(&carton_mutex);
		pthread_mutex_lock(&typeA_mutex);
		char aStatues[10];
		strcpy(aStatues,typeAstatues);
		pthread_mutex_unlock(&typeA_mutex);
		pthread_mutex_lock(&typeB_mutex);
		char bStatues[10];
		strcpy(bStatues,typeBstatues);
		pthread_mutex_unlock(&typeB_mutex);
		pthread_mutex_lock(&typeC_mutex);
		char cStatues[10];
		strcpy(cStatues,typeCstatues);
		pthread_mutex_unlock(&typeC_mutex);
		
		pthread_mutex_lock(&truckStatues_mutex);
		char tStatues[10];
		strcpy(tStatues,truckStatues);
		pthread_mutex_unlock(&truckStatues_mutex);
		
        system("clear");
        pthread_mutex_lock(&console_mutex);
        fprintf(stdout, "\n👋🏼 %s Chocolate-manufacturing factory simulation 🍫 🍪 🍬\n",BHBLU);
 		// Print Product 
		printf(" _______\n");
		for(int i=0; i<5; i++)
		{
		    if(i==0)
		    {
		        printf("|");
		        printf("\t|\t");
		        printf("%s\t 🍮 🤎 INGREDIENTS \n",BHRED );
		        printf("%s", ORIGINAL);
		    }
		    else if(i==1)

		    {
		        printf("|");
		        printf("\t|\n");
		    }
		    else if(i==2)
		    {
		        printf("|  🇵🇸");
		        printf("\t|\t");
		        printf("%s \t   🍚 🍞 FLOUR \n",BHRED );
		        printf("%s", ORIGINAL);
		    }
		    else if(i==3)
		    {
		        printf("|");
		        printf("\t|\t");
		        printf("%s \t     🧂 SALT \n",BHRED);
		        printf("%s", ORIGINAL);
		    }
		    else if(i==4)
		    {
		        printf("|");
		        printf("_______|\t");
		        printf("%s \t     🥛 MILK\n",BHRED);
		        printf("%s", ORIGINAL);
		        printf("|");
		        printf("%s", GREEN_COLOR);
		        printf(" CHOCO |\t");
		        printf("%s \t     🥚 EGG \n",BHRED);	
		        printf("%s", ORIGINAL);
		        printf("|_______|\t");
		        printf("%s \t     🌰 HAZELNUT \n",BHGRN);
		        printf("%s", ORIGINAL);
		        printf("|\t|\n");
		        printf("|__🤎 __|\n");
		    }
		}
		printf("___________________________________________________________________________\n");	
		
		printf(" 🍫 Type A Lines : %s\n",aStatues);
		printf(" 🍫 Type B Lines : %s\n",bStatues);
		printf(" 🍫 Type C Lines : %s\n",cStatues);
		
		printf(" 🍪🍫🍬 Number Of Chocolate In Patch : %d\n",patchCounter);
		//printf(" 🍫 Printing Experation Date Line : %d\n",);
		time_t t = time(NULL);
	   struct tm tm = *localtime(&t);
	   if (patchCounter %10 ==0 && patchCounter !=0 ){
	   printf("\n  🧾Expiration date: %d-%02d-%02d \n", tm.tm_year + 1901, tm.tm_mon + 1, tm.tm_mday);
		}
		printf(" 🍫 Type A Container : %d\n",counterA);
		printf(" 🍪 Type B Container : %d\n",counterB);
		printf(" 🍬 Type C Container : %d\n",counterC);
		
		printf(" 📦 Boxes in storage area : %d\n",cartonN);
		printf(" 🚛🚛🚛 Trucks  : %s\n",tStatues);
		pthread_mutex_unlock(&console_mutex);
        usleep(1500000);

    }

}


void inOrderEmployeeA1(int *line){
	pthread_t thread;
	thread=pthread_self();
	
	while(1){
	pthread_mutex_lock(&pause_mutex);
	int pauseCond=pauseCondition;
	pthread_mutex_unlock(&pause_mutex);
	if (pauseCond==0){
		pthread_mutex_lock(&typeA_mutex);
		strcpy(typeAstatues,"Runing");
		pthread_mutex_unlock(&typeA_mutex);

		sleep(1);
		if (pthread_equal(thread,threadTypeAEmployees[1][1]) || pthread_equal(thread,threadTypeAEmployees[1][2])|| pthread_equal(thread,threadTypeAEmployees[1][3])|| pthread_equal(thread,threadTypeAEmployees[1][4])){
		
			if (pthread_equal(thread,threadTypeAEmployees[1][1])){
				//pthread_mutex_lock(&typeALine1_mutex);
				//counterTypeAEmployeeLine1[0]=counterTypeAEmployeeLine1[0]+1;
				//pthread_mutex_unlock(&typeALine1_mutex);
				struct Chocolate chocolate;
				chocolate.type=1;
				strcpy(chocolate.chocolateType,"A");
				for (int i=0; i<employeeAInAnyOrder ;i++){
					chocolate.stepTypeA[i]=0;
				}
				chocolate.counter=0;
				chocolate.currentStep=1;
				//srand((unsigned) thread);
				sleep(minA_value + (rand() % (maxA_value - minA_value))); 
				//sleep(5);
				msgsnd(typeALine1, &chocolate, sizeof(chocolate), 0);
			}else if (pthread_equal(thread,threadTypeAEmployees[1][2]) || pthread_equal(thread,threadTypeAEmployees[1][3]) || pthread_equal(thread,threadTypeAEmployees[1][4])){
				struct Chocolate chocolate;
				if (pthread_equal(thread,threadTypeAEmployees[1][2])){
					msgrcv(typeALine1, &chocolate, sizeof(chocolate), 1 , 0);
					//pthread_mutex_lock(&typeALine1_mutex);
					//counterTypeAEmployeeLine1[0]=counterTypeAEmployeeLine1[0]-1;
					//pthread_mutex_unlock(&typeALine1_mutex);
					//pthread_mutex_lock(&typeALine1_mutex);
					//counterTypeAEmployeeLine1[1]=counterTypeAEmployeeLine1[1]+1;
					//pthread_mutex_unlock(&typeALine1_mutex);
					chocolate.type=2;
					chocolate.currentStep=2; 
				}else if (pthread_equal(thread,threadTypeAEmployees[1][3])){
					msgrcv(typeALine1, &chocolate, sizeof(chocolate), 2 , 0);
					/*
					pthread_mutex_lock(&typeALine1_mutex);
					counterTypeAEmployeeLine1[1]=counterTypeAEmployeeLine1[1]-1;
					pthread_mutex_unlock(&typeALine1_mutex);
					pthread_mutex_lock(&typeALine1_mutex);
					counterTypeAEmployeeLine1[2]=counterTypeAEmployeeLine1[2]+1;
					pthread_mutex_unlock(&typeALine1_mutex);
					*/
					chocolate.type=3;
					chocolate.currentStep=3;
				}else if (pthread_equal(thread,threadTypeAEmployees[1][4])){
					msgrcv(typeALine1, &chocolate, sizeof(chocolate), 3, 0);
					/*
					pthread_mutex_lock(&typeALine1_mutex);
					counterTypeAEmployeeLine1[2]=counterTypeAEmployeeLine1[2]-1;
					pthread_mutex_unlock(&typeALine1_mutex);
					pthread_mutex_lock(&typeALine1_mutex);
					counterTypeAEmployeeLine1[3]=counterTypeAEmployeeLine1[3]+1;
					pthread_mutex_unlock(&typeALine1_mutex);
					*/									
					chocolate.type=4;
					chocolate.currentStep=4;
					pthread_mutex_lock(&flagA1_mutex);
					flagALine1=0;
					pthread_mutex_unlock(&flagA1_mutex);
					
				}
				strcpy(chocolate.chocolateType,"A");
				for (int i=0; i<employeeAInAnyOrder ;i++){
					chocolate.stepTypeA[i]=0;
				}
				chocolate.counter=0;
				sleep(minA_value + (rand() % (maxA_value - minA_value))); 
				//sleep(5);
				msgsnd(typeALine1, &chocolate, sizeof(chocolate), 0);				
			}
		}
	}
	}
}

void inOrderEmployeeA2(int *line){
	pthread_t thread;
	thread=pthread_self();
	while(1){
	pthread_mutex_lock(&pause_mutex);
	int pauseCond=pauseCondition;
	pthread_mutex_unlock(&pause_mutex);
	if (pauseCond==0){
		pthread_mutex_lock(&typeA_mutex);
		strcpy(typeAstatues,"Runing");
		pthread_mutex_unlock(&typeA_mutex);
	sleep(1);
	if (pthread_equal(thread,threadTypeAEmployees[2][1]) || pthread_equal(thread,threadTypeAEmployees[2][2])|| pthread_equal(thread,threadTypeAEmployees[2][3])|| pthread_equal(thread,threadTypeAEmployees[2][4])){
		
			if (pthread_equal(thread,threadTypeAEmployees[2][1])){
			/*
				pthread_mutex_lock(&typeALine2_mutex);
				counterTypeAEmployeeLine2[0]=counterTypeAEmployeeLine2[0]+1;
				pthread_mutex_unlock(&typeALine2_mutex);
				*/
				struct Chocolate chocolate;
				chocolate.type=1;
				strcpy(chocolate.chocolateType,"A");
				for (int i=0; i<employeeAInAnyOrder ;i++){
					chocolate.stepTypeA[i]=0;
				}
				chocolate.counter=0;
				chocolate.currentStep=1;
				//srand((unsigned) thread);
				sleep(minA_value + (rand() % (maxA_value - minA_value))); 
				//sleep(5);
				msgsnd(typeALine2, &chocolate, sizeof(chocolate), 0);
			}else if (pthread_equal(thread,threadTypeAEmployees[2][2]) || pthread_equal(thread,threadTypeAEmployees[2][3]) || pthread_equal(thread,threadTypeAEmployees[2][4])){
				struct Chocolate chocolate;
				if (pthread_equal(thread,threadTypeAEmployees[2][2])){
					msgrcv(typeALine2, &chocolate, sizeof(chocolate), 1 , 0);
					/*
					pthread_mutex_lock(&typeALine2_mutex);
					counterTypeAEmployeeLine2[0]=counterTypeAEmployeeLine2[0]-1;
					pthread_mutex_unlock(&typeALine2_mutex);
					pthread_mutex_lock(&typeALine2_mutex);
					counterTypeAEmployeeLine2[1]=counterTypeAEmployeeLine2[1]+1;
					pthread_mutex_unlock(&typeALine2_mutex);
					*/
					chocolate.type=2;
					chocolate.currentStep=2; 
				}else if (pthread_equal(thread,threadTypeAEmployees[2][3])){
					msgrcv(typeALine2, &chocolate, sizeof(chocolate), 2 , 0);
					/*
					pthread_mutex_lock(&typeALine2_mutex);
					counterTypeAEmployeeLine2[1]=counterTypeAEmployeeLine2[1]-1;
					pthread_mutex_unlock(&typeALine2_mutex);
					pthread_mutex_lock(&typeALine2_mutex);
					counterTypeAEmployeeLine2[2]=counterTypeAEmployeeLine2[2]+1;
					pthread_mutex_unlock(&typeALine2_mutex);
					*/
					chocolate.type=3;
					chocolate.currentStep=3;
				}else if (pthread_equal(thread,threadTypeAEmployees[2][4])){
					msgrcv(typeALine2, &chocolate, sizeof(chocolate), 3, 0);
					
					/*pthread_mutex_lock(&typeALine2_mutex);
					counterTypeAEmployeeLine2[2]=counterTypeAEmployeeLine2[2]-1;
					pthread_mutex_unlock(&typeALine2_mutex);
					pthread_mutex_lock(&typeALine2_mutex);
					counterTypeAEmployeeLine2[3]=counterTypeAEmployeeLine2[3]+1;
					pthread_mutex_unlock(&typeALine2_mutex);
					*/				
					chocolate.type=4;
					chocolate.currentStep=4;
					pthread_mutex_lock(&flagA2_mutex);
					flagALine2=0;
					pthread_mutex_unlock(&flagA2_mutex);
				}
				strcpy(chocolate.chocolateType,"A");
				for (int i=0; i<employeeAInAnyOrder ;i++){
					chocolate.stepTypeA[i]=0;
				}
				chocolate.counter=0;
				sleep(minA_value + (rand() % (maxA_value - minA_value))); 
				//sleep(5);
				msgsnd(typeALine2, &chocolate, sizeof(chocolate), 0);				
				}
		}	
	}
	}
}
void inOrderEmployeeA3(int *line){
	pthread_t thread;
	thread=pthread_self();
	while(1){
	pthread_mutex_lock(&pause_mutex);
	int pauseCond=pauseCondition;
	pthread_mutex_unlock(&pause_mutex);
	if (pauseCond==0){
		pthread_mutex_lock(&typeA_mutex);
		strcpy(typeAstatues,"Runing");
		pthread_mutex_unlock(&typeA_mutex);
	sleep(1);
			if (pthread_equal(thread,threadTypeAEmployees[3][1]) || pthread_equal(thread,threadTypeAEmployees[3][2])|| pthread_equal(thread,threadTypeAEmployees[3][3])|| pthread_equal(thread,threadTypeAEmployees[3][4])){
			
			if (pthread_equal(thread,threadTypeAEmployees[3][1])){
			/*
				pthread_mutex_lock(&typeALine3_mutex);
				counterTypeAEmployeeLine3[0]=counterTypeAEmployeeLine3[0]+1;
				pthread_mutex_unlock(&typeALine3_mutex);
				*/
				struct Chocolate chocolate;
				chocolate.type=1;
				strcpy(chocolate.chocolateType,"A");
				for (int i=0; i<employeeAInAnyOrder ;i++){
					chocolate.stepTypeA[i]=0;
				}
				chocolate.counter=0;
				chocolate.currentStep=1;
				//srand((unsigned) thread);
				sleep(minA_value + (rand() % (maxA_value - minA_value)));
				//sleep(5); 
				msgsnd(typeALine3, &chocolate, sizeof(chocolate), 0);
			}else if (pthread_equal(thread,threadTypeAEmployees[3][2]) || pthread_equal(thread,threadTypeAEmployees[3][3]) || pthread_equal(thread,threadTypeAEmployees[3][4])){
				struct Chocolate chocolate;
				if (pthread_equal(thread,threadTypeAEmployees[3][2])){
					msgrcv(typeALine3, &chocolate, sizeof(chocolate), 1 , 0);
					/*
					pthread_mutex_lock(&typeALine3_mutex);
					counterTypeAEmployeeLine3[0]=counterTypeAEmployeeLine3[0]-1;
					pthread_mutex_unlock(&typeALine3_mutex);
					pthread_mutex_lock(&typeALine3_mutex);
					counterTypeAEmployeeLine3[1]=counterTypeAEmployeeLine3[1]+1;
					pthread_mutex_unlock(&typeALine3_mutex);
					*/
					chocolate.type=2;
					chocolate.currentStep=2; 
				}else if (pthread_equal(thread,threadTypeAEmployees[3][3])){
					msgrcv(typeALine3, &chocolate, sizeof(chocolate), 2 , 0);
					/*
					pthread_mutex_lock(&typeALine3_mutex);
					counterTypeAEmployeeLine3[1]=counterTypeAEmployeeLine3[1]-1;
					pthread_mutex_unlock(&typeALine3_mutex);
					pthread_mutex_lock(&typeALine3_mutex);
					counterTypeAEmployeeLine3[2]=counterTypeAEmployeeLine3[2]+1;
					pthread_mutex_unlock(&typeALine3_mutex);
					*/
					chocolate.type=3;
					chocolate.currentStep=3;
				}else if (pthread_equal(thread,threadTypeAEmployees[3][4])){
					msgrcv(typeALine3, &chocolate, sizeof(chocolate), 3, 0);
					/*
					pthread_mutex_lock(&typeALine3_mutex);
					counterTypeAEmployeeLine3[2]=counterTypeAEmployeeLine3[2]-1;
					pthread_mutex_unlock(&typeALine3_mutex);
					pthread_mutex_lock(&typeALine3_mutex);
					counterTypeAEmployeeLine3[3]=counterTypeAEmployeeLine3[3]+1;
					pthread_mutex_unlock(&typeALine3_mutex);	
					*/
					chocolate.type=4;
					chocolate.currentStep=3;
					pthread_mutex_lock(&flagA3_mutex);
					flagALine3=0;
					pthread_mutex_unlock(&flagA3_mutex);
				}
				strcpy(chocolate.chocolateType,"A");
				for (int i=0; i<employeeAInAnyOrder ;i++){
					chocolate.stepTypeA[i]=0;
				}
				chocolate.counter=0;
				sleep(minA_value + (rand() % (maxA_value - minA_value))); 
				//sleep(5);
				msgsnd(typeALine3, &chocolate, sizeof(chocolate), 0);		
			}
		}
	
	}
	}
}

void inAnyOrderEmployeeA1(int *line){
	pthread_t thread;
	thread=pthread_self();
	while(1){
	pthread_mutex_lock(&pause_mutex);
	int pauseCond=pauseCondition;
	pthread_mutex_unlock(&pause_mutex);
	if (pauseCond==0){
	sleep(1);
	if (pthread_equal(thread,threadTypeAEmployees[1][5]) || pthread_equal(thread,threadTypeAEmployees[1][6])|| pthread_equal(thread,threadTypeAEmployees[1][7])|| pthread_equal(thread,threadTypeAEmployees[1][8])){
			
		if(flagALine1==0){ 
				int randstep= 5 + (rand() % ( 9 - 5 )); 
				//printf("%d-------------------------",randstep);
			if (pthread_equal(thread,threadTypeAEmployees[1][randstep]) || pthread_equal(thread,threadTypeAEmployees[1][randstep]) || pthread_equal(thread,threadTypeAEmployees[1][randstep]) || pthread_equal(thread,threadTypeAEmployees[1][randstep])){
				//srand((unsigned) thread);
				
				struct Chocolate chocolate;
				msgrcv(typeALine1, &chocolate, sizeof(chocolate), 4 , 0);
				/*
				pthread_mutex_lock(&typeALine1_mutex);
				counterTypeAEmployeeLine1[3]=counterTypeAEmployeeLine1[3]-1;
				pthread_mutex_unlock(&typeALine1_mutex);
				pthread_mutex_lock(&typeALine1_mutex);
				counterTypeAEmployeeLine1[randstep-1]=counterTypeAEmployeeLine1[randstep-1]+1;
				pthread_mutex_unlock(&typeALine1_mutex);
				*/
				chocolate.counter=1;
				chocolate.currentStep=5;					
				if (pthread_equal(threadTypeAEmployees[1][randstep],threadTypeAEmployees[1][5])){
					chocolate.stepTypeA[0]=1;
					chocolate.previouesEmployeeStep=randstep-1;
				}else if (pthread_equal(threadTypeAEmployees[1][randstep],threadTypeAEmployees[1][6])){		       
				        chocolate.stepTypeA[1]=1;
				        chocolate.previouesEmployeeStep=randstep-1;
				}else if (pthread_equal(threadTypeAEmployees[1][randstep],threadTypeAEmployees[1][7])){
			         chocolate.stepTypeA[2]=1;
			         chocolate.previouesEmployeeStep=randstep-1;				         
			    }else if (pthread_equal(threadTypeAEmployees[1][randstep],threadTypeAEmployees[1][8])){		
					chocolate.previouesEmployeeStep=randstep-1;		
				    chocolate.stepTypeA[3]=1;
			    }
				chocolate.type=randstep;
				strcpy(chocolate.chocolateType,"A");
				
				sleep(minA_value + (rand() % (maxA_value - minA_value))); 
				//sleep(5);
				msgsnd(typeALine1, &chocolate, sizeof(chocolate), 0);
				pthread_mutex_lock(&flagA1_mutex);
				flagALine1=1;
				pthread_mutex_unlock(&flagA1_mutex);
			}
		}else if(flagALine1==1){
			//srand((unsigned) thread);
			int randstep= 5 + (rand() % ( 9 - 5 )); 
			//printf("%d-------------------------",randstep);
			struct Chocolate chocolate;
			if ((pthread_equal(threadTypeAEmployees[1][randstep],threadTypeAEmployees[1][5]) && chocolate.stepTypeA[0] !=1) || (pthread_equal(threadTypeAEmployees[1][randstep],threadTypeAEmployees[1][6]) && chocolate.stepTypeA[1] !=1) || (pthread_equal(threadTypeAEmployees[1][randstep],threadTypeAEmployees[1][7]) && chocolate.stepTypeA[2] !=1) || (pthread_equal(threadTypeAEmployees[1][randstep],threadTypeAEmployees[1][8]) && chocolate.stepTypeA[3] !=1)){
				msgrcv(typeALine1, &chocolate, sizeof(chocolate), chocolate.type , 0);
				/*
				pthread_mutex_lock(&typeALine1_mutex);
				counterTypeAEmployeeLine1[chocolate.previouesEmployeeStep]=counterTypeAEmployeeLine1[chocolate.previouesEmployeeStep]-1;
				pthread_mutex_unlock(&typeALine1_mutex);
				pthread_mutex_lock(&typeALine1_mutex);
				counterTypeAEmployeeLine1[randstep-1]=counterTypeAEmployeeLine1[randstep-1]+1;
				pthread_mutex_unlock(&typeALine1_mutex);
				*/
				int counter=chocolate.counter+1;
				if (counter == 4){
					chocolate.counter=counter;
					int stepNum=chocolate.currentStep+1;
					chocolate.currentStep=stepNum;
					if(pthread_equal(threadTypeAEmployees[1][randstep],threadTypeAEmployees[1][5])){
						chocolate.stepTypeA[0]=1;
					}else if(pthread_equal(threadTypeAEmployees[1][randstep],threadTypeAEmployees[1][6])){
						chocolate.stepTypeA[1]=1;
					}else if(pthread_equal(threadTypeAEmployees[1][randstep],threadTypeAEmployees[1][7])){
						chocolate.stepTypeA[2]=1;
					}else if(pthread_equal(threadTypeAEmployees[1][randstep],threadTypeAEmployees[1][8])){
						chocolate.stepTypeA[3]=1;
					}
					chocolate.type=1;
					strcpy(chocolate.chocolateType,"A");
					msgsnd(Patch, &chocolate, sizeof(chocolate), 0);
					pthread_mutex_lock(&patchCounter_mutex);
					patch_counter=patch_counter+1;
					pthread_mutex_unlock(&patchCounter_mutex);
					//printf("send to patch A1-----------------------------------------------\n");
					//fflush(stdout);
				}else { 
					chocolate.counter=counter;
					int stepNum=chocolate.currentStep+1;
					chocolate.currentStep=stepNum;
					if(pthread_equal(threadTypeAEmployees[1][randstep],threadTypeAEmployees[1][5])){
						chocolate.stepTypeA[0]=1;
					}else if(pthread_equal(threadTypeAEmployees[1][randstep],threadTypeAEmployees[1][6])){
						chocolate.stepTypeA[1]=1;
					}else if(pthread_equal(threadTypeAEmployees[1][randstep],threadTypeAEmployees[1][7])){
						chocolate.stepTypeA[2]=1;
					}else if(pthread_equal(threadTypeAEmployees[1][randstep],threadTypeAEmployees[1][8])){
						chocolate.stepTypeA[3]=1;
					}
					chocolate.previouesEmployeeStep=randstep-1;
					chocolate.type=randstep;
					strcpy(chocolate.chocolateType,"A");
					sleep(minA_value + (rand() % (maxA_value - minA_value))); 
					//sleep(5);
					msgsnd(typeALine1, &chocolate, sizeof(chocolate), 0);
					//pthread_mutex_lock(&flagA1_mutex);
					//flagALine1=1;
					//pthread_mutex_unlock(&flagA1_mutex);
				}
			}
		}
	}
		
	}	
	}
}

void inAnyOrderEmployeeA2(int *line){
	pthread_t thread;
	thread=pthread_self();
	while(1){
	pthread_mutex_lock(&pause_mutex);
	int pauseCond=pauseCondition;
	pthread_mutex_unlock(&pause_mutex);
	if (pauseCond==0){
	sleep(1);
	if (pthread_equal(thread,threadTypeAEmployees[2][5]) || pthread_equal(thread,threadTypeAEmployees[2][6])|| pthread_equal(thread,threadTypeAEmployees[2][7])|| pthread_equal(thread,threadTypeAEmployees[2][8])){
				
			if(flagALine2==0){ 
				//srand((unsigned) thread);
				int randstep= 5 + (rand() % ( 9 - 5 )); 
				//printf("%d-----------------------------------------------------------------------------------------------------\n",randstep);
				//fflush(stdout);
				if (pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][5]) || pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][6]) || pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][7]) || pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][8])){
					struct Chocolate chocolate;
					msgrcv(typeALine2, &chocolate, sizeof(chocolate), 4 , 0);
					/*
					pthread_mutex_lock(&typeALine2_mutex);
					counterTypeAEmployeeLine2[3]=counterTypeAEmployeeLine2[3]-1;
					pthread_mutex_unlock(&typeALine2_mutex);
					pthread_mutex_lock(&typeALine2_mutex);
					counterTypeAEmployeeLine2[randstep-1]=counterTypeAEmployeeLine2[randstep-1]+1;
					pthread_mutex_unlock(&typeALine2_mutex);
					*/
					chocolate.counter=1;
					chocolate.currentStep=5;					
					if (pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][5])){
						chocolate.stepTypeA[0]=1;
						chocolate.previouesEmployeeStep=randstep-1;
						}
					else if (pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][6])){			       
				        chocolate.stepTypeA[1]=1;
				        chocolate.previouesEmployeeStep=randstep-1;
					}else if (pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][7])){
				         chocolate.stepTypeA[2]=1;
				         chocolate.previouesEmployeeStep=randstep-1;   
					}else if (pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][8])){		
						chocolate.previouesEmployeeStep=randstep-1;	
					    chocolate.stepTypeA[3]=1;
					}
					chocolate.type=randstep;
					strcpy(chocolate.chocolateType,"A");
					sleep(minA_value + (rand() % (maxA_value - minA_value))); 
					//sleep(5);
					msgsnd(typeALine2, &chocolate, sizeof(chocolate), 0);
					pthread_mutex_lock(&flagA2_mutex);
					flagALine2=1;
					pthread_mutex_unlock(&flagA2_mutex);
				}
			}else if(flagALine2==1){
				//srand((unsigned) thread);
				int randstep= 5 + (rand() % ( 9 - 5 )); 
				//printf("%d-----------------------------------------------------------------------------------------------------\n",randstep);
				//fflush(stdout);
				struct Chocolate chocolate;
				if ((pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][5]) && chocolate.stepTypeA[0] !=1) ||  (pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][6]) && chocolate.stepTypeA[1] !=1) || (pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][7]) && chocolate.stepTypeA[2] !=1) || (pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][8]) && chocolate.stepTypeA[3] !=1)){
					msgrcv(typeALine2, &chocolate, sizeof(chocolate), chocolate.type , 0);
					/*
					pthread_mutex_lock(&typeALine2_mutex);
					counterTypeAEmployeeLine2[chocolate.previouesEmployeeStep]=counterTypeAEmployeeLine2[chocolate.previouesEmployeeStep]-1;
					pthread_mutex_unlock(&typeALine2_mutex);
					pthread_mutex_lock(&typeALine2_mutex);
					counterTypeAEmployeeLine2[randstep-1]=counterTypeAEmployeeLine2[randstep-1]+1;
					pthread_mutex_unlock(&typeALine2_mutex);
					*/
					int counter=chocolate.counter+1;
					if (counter == 4){
						chocolate.counter=counter;
						int stepNum=chocolate.currentStep+1;
						chocolate.currentStep=stepNum;
						if (pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][5])){
							chocolate.stepTypeA[0]=1;
						}
						if (pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][6])){
							chocolate.stepTypeA[1]=1;
						}
						if (pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][7])){
							chocolate.stepTypeA[2]=1;
						}
						if (pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][8])){
							chocolate.stepTypeA[3]=1;
						}
						chocolate.type=1;
						strcpy(chocolate.chocolateType,"A");
						msgsnd(Patch, &chocolate, sizeof(chocolate), 0);
						pthread_mutex_lock(&patchCounter_mutex);
						patch_counter=patch_counter+1;
						pthread_mutex_unlock(&patchCounter_mutex);
						//printf("send to patch A2----------------------------------------------------------\n");
						//fflush(stdout);
					}
					else { 
						chocolate.counter=counter;
						int stepNum=chocolate.currentStep+1;
						chocolate.currentStep=stepNum;
						if (pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][5])){
							chocolate.stepTypeA[0]=1;
						}
						if (pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][6])){
							chocolate.stepTypeA[1]=1;
						}
						if (pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][7])){
							chocolate.stepTypeA[2]=1;
						}
						if (pthread_equal(threadTypeAEmployees[2][randstep],threadTypeAEmployees[2][8])){
							chocolate.stepTypeA[3]=1;
						}
						chocolate.previouesEmployeeStep=randstep-1;
						chocolate.type=randstep;
						strcpy(chocolate.chocolateType,"A");
						sleep(minA_value + (rand() % (maxA_value - minA_value))); 
						//sleep(5);
						msgsnd(typeALine2, &chocolate, sizeof(chocolate), 0);
						//pthread_mutex_lock(&flagA2_mutex);
						//flagALine2=1;
						//pthread_mutex_unlock(&flagA2_mutex);
					}
			}
			}		
		}
	}
	}
	
}

void inAnyOrderEmployeeA3(int *line){
	pthread_t thread;
	thread=pthread_self();
	while(1){
	pthread_mutex_lock(&pause_mutex);
	int pauseCond=pauseCondition;
	pthread_mutex_unlock(&pause_mutex);
	if (pauseCond==0){
	sleep(1);
		if (pthread_equal(thread,threadTypeAEmployees[3][5]) || pthread_equal(thread,threadTypeAEmployees[3][6])|| pthread_equal(thread,threadTypeAEmployees[3][7])|| pthread_equal(thread,threadTypeAEmployees[3][8])){
			
			if(flagALine3==0){ 
				//srand((unsigned) thread);
				int randstep= 5 + (rand() % ( 9 - 5 )); 
				//printf("%d-----------------------------------------------------------------------------------------\n",randstep);
				//fflush(stdout);
				if (pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][5]) || pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][6]) || pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][7]) || pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][8])){
					struct Chocolate chocolate;
					msgrcv(typeALine3, &chocolate, sizeof(chocolate), 4 , 0);
					/*
					pthread_mutex_lock(&typeALine3_mutex);
					counterTypeAEmployeeLine3[3]=counterTypeAEmployeeLine3[3]-1;
					pthread_mutex_unlock(&typeALine3_mutex);
					pthread_mutex_lock(&typeALine3_mutex);
					counterTypeAEmployeeLine3[randstep-1]=counterTypeAEmployeeLine3[randstep-1]+1;
					pthread_mutex_unlock(&typeALine3_mutex);
					*/
					chocolate.counter=1;
					chocolate.currentStep=5;				
					if (pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][5])){
						chocolate.stepTypeA[0]=1;
						chocolate.previouesEmployeeStep=randstep-1;
					}else if (pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][6])){
					        chocolate.stepTypeA[1]=1;
					        chocolate.previouesEmployeeStep=randstep-1;
					}else if (pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][7])){
					         chocolate.stepTypeA[2]=1;
					         chocolate.previouesEmployeeStep=randstep-1;					         
					}else if (pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][8])){					
							chocolate.previouesEmployeeStep=randstep-1;			
						    chocolate.stepTypeA[3]=1;
					}
					chocolate.type=randstep;
					strcpy(chocolate.chocolateType,"A");
					sleep(minA_value + (rand() % (maxA_value - minA_value))); 
					//sleep(5);
					msgsnd(typeALine3, &chocolate, sizeof(chocolate), 0);
					pthread_mutex_lock(&flagA3_mutex);
					flagALine3=1;
					pthread_mutex_unlock(&flagA3_mutex);
				}
			}
			else if(flagALine3 ==1) {
				//srand((unsigned) thread);
				int randstep= 5 + (rand() % ( 9 - 5 )); 
				//printf("%d-----------------------------------------------------------------------------------------\n",randstep);
				//fflush(stdout);
				struct Chocolate chocolate;
				if ((pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][5]) && chocolate.stepTypeA[0] !=1) || (pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][6]) && chocolate.stepTypeA[1] !=1) || (pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][7]) && chocolate.stepTypeA[2] !=1) || (pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][8]) && chocolate.stepTypeA[3] !=1)){
					
					msgrcv(typeALine3, &chocolate, sizeof(chocolate), chocolate.type , 0);
					/*
					pthread_mutex_lock(&typeALine3_mutex);
					counterTypeAEmployeeLine3[chocolate.previouesEmployeeStep]=counterTypeAEmployeeLine3[chocolate.previouesEmployeeStep]-1;
					pthread_mutex_unlock(&typeALine3_mutex);
					pthread_mutex_lock(&typeALine3_mutex);
					counterTypeAEmployeeLine3[randstep-1]=counterTypeAEmployeeLine3[randstep-1]+1;
					pthread_mutex_unlock(&typeALine3_mutex);
					*/
					int counter=chocolate.counter+1;
					if (counter == 4){
						chocolate.counter=counter;
						int stepNum=chocolate.currentStep+1;
						chocolate.currentStep=stepNum;
						if (pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][5])){
							chocolate.stepTypeA[0]=1;
						}
						if (pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][6])){
							chocolate.stepTypeA[1]=1;
						}
						if (pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][7])){
							chocolate.stepTypeA[2]=1;
						}
						if (pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][8])){
							chocolate.stepTypeA[3]=1;
						}
						chocolate.type=1;
						strcpy(chocolate.chocolateType,"A");
						msgsnd(Patch, &chocolate, sizeof(chocolate), 0);
				pthread_mutex_lock(&patchCounter_mutex);
				patch_counter=patch_counter+1;
				pthread_mutex_unlock(&patchCounter_mutex);
						//printf("send to patch A3-------------------------------------------------------------\n");
						//fflush(stdout);
					}
					else { 
						chocolate.counter=counter;
						int stepNum=chocolate.currentStep+1;
						chocolate.currentStep=stepNum;
						if (pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][5])){
							chocolate.stepTypeA[0]=1;
						}
						if (pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][6])){
							chocolate.stepTypeA[1]=1;
						}
						if (pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][7])){
							chocolate.stepTypeA[2]=1;
						}
						if (pthread_equal(threadTypeAEmployees[3][randstep],threadTypeAEmployees[3][8])){
							chocolate.stepTypeA[3]=1;
						}
						chocolate.previouesEmployeeStep=randstep-1;
						chocolate.type=randstep;
						strcpy(chocolate.chocolateType,"A");
						sleep(minA_value + (rand() % (maxA_value - minA_value))); 
						//sleep(5);
						msgsnd(typeALine3, &chocolate, sizeof(chocolate), 0);
						//pthread_mutex_lock(&flagA3_mutex);
						//flagALine3=1;
						//pthread_mutex_unlock(&flagA3_mutex);
					}
				}
			}
		}
	}	
	}
}


void typeBThread(int *line_number){
	pthread_t thread;
	thread=pthread_self();
	int line1=1;
	int line2=2;
	while(1){
	sleep(1);
	//for (int i=0; i<2;i++){
		
		if (pthread_equal(thread,threadidTypeB[0])){
			for (int i=1; i<=employeeBNumbers; i++){
				pthread_create(&threadTypeBEmployees[1][i], NULL,(void *) inOrderEmployeeB1,(void *) &line1); 
				sleep(4);		
			}
			
		}
		if (pthread_equal(thread,threadidTypeB[1])){
			for (int i=1; i<=employeeBNumbers; i++){
				pthread_create(&threadTypeBEmployees[2][i], NULL,(void *) inOrderEmployeeB2,(void *) &line2); 
				sleep(4);	
			}
				
		}
		for (int i=1; i<=employeeBNumbers; i++){
				pthread_join(threadTypeBEmployees[1][i], NULL);
				pthread_join(threadTypeBEmployees[2][i], NULL);
		}
  }	
}

void inOrderEmployeeB1(int *line){

	pthread_t thread;
	thread=pthread_self();
	while(1){
	
	pthread_mutex_lock(&pause_mutex);
	int pauseCond=pauseCondition;
	pthread_mutex_unlock(&pause_mutex);
	if (pauseCond==0){
	pthread_mutex_lock(&typeB_mutex);
	strcpy(typeBstatues,"Runing");
	pthread_mutex_unlock(&typeB_mutex);
	
		sleep(1);
		if (pthread_equal(thread,threadTypeBEmployees[1][1]) || pthread_equal(thread,threadTypeBEmployees[1][2])|| pthread_equal(thread,threadTypeBEmployees[1][3])|| pthread_equal(thread,threadTypeBEmployees[1][4])|| pthread_equal(thread,threadTypeBEmployees[1][5])||pthread_equal(thread,threadTypeBEmployees[1][6])){
		
			if (pthread_equal(thread,threadTypeBEmployees[1][1])){
			/*
				pthread_mutex_lock(&typeBLine1_mutex);
				counterTypeBEmployeeLine1[0]=counterTypeBEmployeeLine1[0]+1;
				pthread_mutex_unlock(&typeBLine1_mutex);
				*/
				struct Chocolate chocolate;
				chocolate.type=1;
				strcpy(chocolate.chocolateType,"B");
				chocolate.counter=0;
				chocolate.currentStep=1;
				//srand((unsigned) thread);
				sleep(minB_value + (rand() % (maxB_value - minB_value))); 
				//sleep(5);
				msgsnd(typeBLine1, &chocolate, sizeof(chocolate), 0);
			}else if (pthread_equal(thread,threadTypeBEmployees[1][2]) || pthread_equal(thread,threadTypeBEmployees[1][3]) || pthread_equal(thread,threadTypeBEmployees[1][4])|| pthread_equal(thread,threadTypeBEmployees[1][5])||pthread_equal(thread,threadTypeBEmployees[1][6])){
				struct Chocolate chocolate;
				if (pthread_equal(thread,threadTypeBEmployees[1][2])){
					msgrcv(typeBLine1, &chocolate, sizeof(chocolate), 1 , 0);
					/*
					pthread_mutex_lock(&typeBLine1_mutex);
					counterTypeBEmployeeLine1[0]=counterTypeBEmployeeLine1[0]-1;
					pthread_mutex_unlock(&typeBLine1_mutex);
					pthread_mutex_lock(&typeBLine1_mutex);
					counterTypeBEmployeeLine1[1]=counterTypeBEmployeeLine1[1]+1;
					pthread_mutex_unlock(&typeBLine1_mutex);
					*/
					chocolate.type=2;
					
					chocolate.currentStep=2; 
				}else if (pthread_equal(thread,threadTypeBEmployees[1][3])){
					msgrcv(typeBLine1, &chocolate, sizeof(chocolate), 2 , 0);
					/*
					pthread_mutex_lock(&typeBLine1_mutex);
					counterTypeBEmployeeLine1[1]=counterTypeBEmployeeLine1[1]-1;
					pthread_mutex_unlock(&typeBLine1_mutex);
					pthread_mutex_lock(&typeBLine1_mutex);
					counterTypeBEmployeeLine1[2]=counterTypeBEmployeeLine1[2]+1;
					pthread_mutex_unlock(&typeBLine1_mutex);
					*/
					chocolate.type=3;
					chocolate.currentStep=3;
				}else if (pthread_equal(thread,threadTypeBEmployees[1][4])){
					msgrcv(typeBLine1, &chocolate, sizeof(chocolate), 3, 0);
					/*
					pthread_mutex_lock(&typeBLine1_mutex);
					counterTypeBEmployeeLine1[2]=counterTypeBEmployeeLine1[2]-1;
					pthread_mutex_unlock(&typeBLine1_mutex);
					pthread_mutex_lock(&typeBLine1_mutex);
					counterTypeBEmployeeLine1[3]=counterTypeBEmployeeLine1[3]+1;
					pthread_mutex_unlock(&typeBLine1_mutex);
					*/									
					chocolate.type=4;
					chocolate.currentStep=4;
				}else if (pthread_equal(thread,threadTypeBEmployees[1][5])){
					msgrcv(typeBLine1, &chocolate, sizeof(chocolate), 4, 0);
					/*
					pthread_mutex_lock(&typeBLine1_mutex);
					counterTypeBEmployeeLine1[3]=counterTypeBEmployeeLine1[3]-1;
					pthread_mutex_unlock(&typeBLine1_mutex);
					pthread_mutex_lock(&typeBLine1_mutex);
					counterTypeBEmployeeLine1[4]=counterTypeBEmployeeLine1[4]+1;
					pthread_mutex_unlock(&typeBLine1_mutex);
					*/									
					chocolate.type=5;
					chocolate.currentStep=5;
				}else if (pthread_equal(thread,threadTypeBEmployees[1][6])){
					msgrcv(typeBLine1, &chocolate, sizeof(chocolate), 5, 0);
					/*
					pthread_mutex_lock(&typeBLine1_mutex);
					counterTypeBEmployeeLine1[4]=counterTypeBEmployeeLine1[4]-1;
					pthread_mutex_unlock(&typeBLine1_mutex);
					pthread_mutex_lock(&typeBLine1_mutex);
					counterTypeBEmployeeLine1[5]=counterTypeBEmployeeLine1[5]+1;
					pthread_mutex_unlock(&typeBLine1_mutex);	
					*/								
					chocolate.type=6;
					chocolate.currentStep=6;
					
				}
				strcpy(chocolate.chocolateType,"B");
				chocolate.counter=0;
				sleep(minB_value + (rand() % (maxB_value - minB_value))); 
				//sleep(5);
				if (chocolate.type == 6){
				chocolate.type = 2;
				msgsnd(Patch, &chocolate, sizeof(chocolate), 0);
				pthread_mutex_lock(&patchCounter_mutex);
				patch_counter=patch_counter+1;
				pthread_mutex_unlock(&patchCounter_mutex);
					//printf("send to patch B1\n");
					//fflush(stdout);
				}else{
				msgsnd(typeBLine1, &chocolate, sizeof(chocolate), 0);				
			}
			}
		}
		
		
	}
	}
}

void inOrderEmployeeB2(int *line){

	pthread_t thread;
	thread=pthread_self();
	while(1){
	pthread_mutex_lock(&pause_mutex);
	int pauseCond=pauseCondition;
	pthread_mutex_unlock(&pause_mutex);
	if (pauseCond==0){
		pthread_mutex_lock(&typeB_mutex);
		strcpy(typeBstatues,"Runing");
		pthread_mutex_unlock(&typeB_mutex);
		sleep(1);
		if (pthread_equal(thread,threadTypeBEmployees[2][1]) || pthread_equal(thread,threadTypeBEmployees[2][2])|| pthread_equal(thread,threadTypeBEmployees[2][3])|| pthread_equal(thread,threadTypeBEmployees[2][4])|| pthread_equal(thread,threadTypeBEmployees[2][5])||pthread_equal(thread,threadTypeBEmployees[2][6])){
		
			if (pthread_equal(thread,threadTypeBEmployees[2][1])){
			/*
				pthread_mutex_lock(&typeBLine2_mutex);
				counterTypeBEmployeeLine2[0]=counterTypeBEmployeeLine2[0]+1;
				pthread_mutex_unlock(&typeBLine2_mutex);
				*/
				struct Chocolate chocolate;
				chocolate.type=1;
				strcpy(chocolate.chocolateType,"B");
				chocolate.counter=0;
				chocolate.currentStep=1;
				//srand((unsigned) thread);
				sleep(minB_value + (rand() % (maxB_value - minB_value))); 
				//sleep(5);
				msgsnd(typeBLine2, &chocolate, sizeof(chocolate), 0);
			}else if (pthread_equal(thread,threadTypeBEmployees[2][2]) || pthread_equal(thread,threadTypeBEmployees[2][3]) || pthread_equal(thread,threadTypeBEmployees[2][4])|| pthread_equal(thread,threadTypeBEmployees[2][5])||pthread_equal(thread,threadTypeBEmployees[2][6])){
				struct Chocolate chocolate;
				if (pthread_equal(thread,threadTypeBEmployees[2][2])){
					msgrcv(typeBLine2, &chocolate, sizeof(chocolate), 1 , 0);
					/*
					pthread_mutex_lock(&typeBLine2_mutex);
					counterTypeBEmployeeLine2[0]=counterTypeBEmployeeLine2[0]-1;
					pthread_mutex_unlock(&typeBLine2_mutex);
					pthread_mutex_lock(&typeBLine2_mutex);
					counterTypeBEmployeeLine2[1]=counterTypeBEmployeeLine2[1]+1;
					pthread_mutex_unlock(&typeBLine2_mutex);
					*/
					chocolate.type=2;
					chocolate.currentStep=2; 
				}else if (pthread_equal(thread,threadTypeBEmployees[2][3])){
					msgrcv(typeBLine2, &chocolate, sizeof(chocolate), 2 , 0);
					/*
					pthread_mutex_lock(&typeBLine2_mutex);
					counterTypeBEmployeeLine2[1]=counterTypeBEmployeeLine2[1]-1;
					pthread_mutex_unlock(&typeBLine2_mutex);
					pthread_mutex_lock(&typeBLine2_mutex);
					counterTypeBEmployeeLine2[2]=counterTypeBEmployeeLine2[2]+1;
					pthread_mutex_unlock(&typeBLine2_mutex);
					*/
					chocolate.type=3;
					chocolate.currentStep=3;
				}else if (pthread_equal(thread,threadTypeBEmployees[2][4])){
					msgrcv(typeBLine2, &chocolate, sizeof(chocolate), 3, 0);
					/*
					pthread_mutex_lock(&typeBLine2_mutex);
					counterTypeBEmployeeLine2[2]=counterTypeBEmployeeLine2[2]-1;
					pthread_mutex_unlock(&typeBLine2_mutex);
					pthread_mutex_lock(&typeBLine2_mutex);
					counterTypeBEmployeeLine2[3]=counterTypeBEmployeeLine2[3]+1;
					pthread_mutex_unlock(&typeBLine2_mutex);	
					*/								
					chocolate.type=4;
					chocolate.currentStep=4;
				}else if (pthread_equal(thread,threadTypeBEmployees[2][5])){
					msgrcv(typeBLine2, &chocolate, sizeof(chocolate), 4, 0);
					/*
					pthread_mutex_lock(&typeBLine2_mutex);
					counterTypeBEmployeeLine2[3]=counterTypeBEmployeeLine2[3]-1;
					pthread_mutex_unlock(&typeBLine2_mutex);
					pthread_mutex_lock(&typeBLine2_mutex);
					counterTypeBEmployeeLine2[4]=counterTypeBEmployeeLine2[4]+1;
					pthread_mutex_unlock(&typeBLine2_mutex);	
					*/								
					chocolate.type=5;
					chocolate.currentStep=5;
				}else if (pthread_equal(thread,threadTypeBEmployees[2][6])){
					msgrcv(typeBLine2, &chocolate, sizeof(chocolate), 5, 0);
					/*
					pthread_mutex_lock(&typeBLine2_mutex);
					counterTypeBEmployeeLine2[4]=counterTypeBEmployeeLine2[4]-1;
					pthread_mutex_unlock(&typeBLine2_mutex);
					pthread_mutex_lock(&typeBLine2_mutex);
					counterTypeBEmployeeLine2[5]=counterTypeBEmployeeLine2[5]+1;
					pthread_mutex_unlock(&typeBLine2_mutex);
					*/									
					chocolate.type=6;
					chocolate.currentStep=6;
				}
				strcpy(chocolate.chocolateType,"B");
				chocolate.counter=0;
				sleep(minB_value + (rand() % (maxB_value - minB_value))); 
				//sleep(5);
				if (chocolate.type == 6){
				chocolate.type = 2;
				msgsnd(Patch, &chocolate, sizeof(chocolate), 0);
				pthread_mutex_lock(&patchCounter_mutex);
				patch_counter=patch_counter+1;
				pthread_mutex_unlock(&patchCounter_mutex);
					//printf("send to patch B2\n");
					//fflush(stdout);
				}else{
				msgsnd(typeBLine2, &chocolate, sizeof(chocolate), 0);				
			}
			}
		}
	}
	}
}

// Type c Line 
void typeCThread(int *line_number){
	pthread_t thread;
	thread=pthread_self();
	int line1=1;
	int line2=2;
	while(1){
		sleep(1);
		if (pthread_equal(thread,threadidTypeC[0])){
			for (int i=1; i<=employeeCNumbers; i++){
				if (i >=1 && i<=3){
					pthread_create(&threadTypeCEmployees[1][i], NULL,(void *) inOrderEmployeeC1,(void *) &line1); // in order steps
				}else {
					pthread_create(&threadTypeCEmployees[1][i], NULL,(void *) inAnyOrderEmployeeC1,(void *) &line1); // in any order steps
				}
				sleep(4);		
			}
		}
		
		if (pthread_equal(thread,threadidTypeC[1])){
			for (int i=1; i<=employeeCNumbers; i++){
				if (i >=1 && i<=3){
					pthread_create(&threadTypeCEmployees[2][i], NULL,(void *) inOrderEmployeeC2,(void *) &line2); // in order steps 
				}else {
					pthread_create(&threadTypeCEmployees[2][i], NULL,(void *) inAnyOrderEmployeeC2,(void *) &line2); // in any order steps
				}
				sleep(4);	
			}	
		}
		
		for (int i=1; i<=employeeCNumbers; i++){
			pthread_join(threadTypeCEmployees[1][i], NULL);
			pthread_join(threadTypeCEmployees[2][i], NULL);
		}
	}
}

void inOrderEmployeeC1(){
	pthread_t thread;
	thread=pthread_self();
	struct Chocolate chocolate;
	while(1){
	pthread_mutex_lock(&pause_mutex);
	int pauseCond=pauseCondition;
	pthread_mutex_unlock(&pause_mutex);
	if (pauseCond==0){
		pthread_mutex_lock(&typeC_mutex);
		strcpy(typeCstatues,"Runing");
		pthread_mutex_unlock(&typeC_mutex);
		sleep(1);
		if (pthread_equal(thread,threadTypeCEmployees[1][1]) || pthread_equal(thread,threadTypeCEmployees[1][2])|| pthread_equal(thread,threadTypeCEmployees[1][3])){
			if (pthread_equal(thread,threadTypeCEmployees[1][1])){
				chocolate.type=1;
				strcpy(chocolate.chocolateType,"C");
				for (int i=0; i<employeeCInAnyOrder ;i++){
					chocolate.stepTypeC[i]=0;
				}
				chocolate.counter=0;
				chocolate.currentStep=1;
				sleep(minC_value + (rand() % (maxC_value - minC_value))); 
				msgsnd(typeCLine1, &chocolate, sizeof(chocolate), 0);
			}else if (pthread_equal(thread,threadTypeCEmployees[1][2])){
				msgrcv(typeCLine1, &chocolate, sizeof(chocolate), 1 , 0);
				chocolate.type=2;
				strcpy(chocolate.chocolateType,"C");
				for (int i=0; i<employeeCInAnyOrder ;i++){
					chocolate.stepTypeC[i]=0;
				}
				chocolate.counter=0;
				chocolate.currentStep=2;
				sleep(minC_value + (rand() % (maxC_value - minC_value))); 
				msgsnd(typeCLine1, &chocolate, sizeof(chocolate), 0);
			}else if (pthread_equal(thread,threadTypeCEmployees[1][3])){
				msgrcv(typeCLine1, &chocolate, sizeof(chocolate), 2 , 0);
				chocolate.type=3;
				strcpy(chocolate.chocolateType,"C");
				for (int i=0; i<employeeCInAnyOrder ;i++){
					chocolate.stepTypeC[i]=0;
				}
				chocolate.counter=0;
				chocolate.currentStep=3;
				sleep(minC_value + (rand() % (maxC_value - minC_value)));
				
				pthread_mutex_lock(&flagC1_mutex);
				flagCLine1=0;
				pthread_mutex_unlock(&flagC1_mutex); 
				
				msgsnd(typeCLine1, &chocolate, sizeof(chocolate), 0);
			}	
		}	
	}
	}
}


void inAnyOrderEmployeeC1(int *line){
	pthread_t thread;
	thread=pthread_self();
	while(1){
	pthread_mutex_lock(&pause_mutex);
	int pauseCond=pauseCondition;
	pthread_mutex_unlock(&pause_mutex);
	if (pauseCond==0){
		pthread_mutex_lock(&typeC_mutex);
		strcpy(typeCstatues,"Runing");
		pthread_mutex_unlock(&typeC_mutex);
	sleep(1);
		if (pthread_equal(thread,threadTypeCEmployees[1][4]) || pthread_equal(thread,threadTypeCEmployees[1][5])){
			if(flagCLine1==0){ 	
				//if (pthread_equal(thread,threadTypeCEmployees[1][4])){
				struct Chocolate chocolate;
				msgrcv(typeCLine1, &chocolate, sizeof(chocolate), 3 , 0);
				chocolate.type=4;
				chocolate.counter=1;
				chocolate.currentStep=4;
				sleep(minC_value + (rand() % (maxC_value - minC_value))); 
				msgsnd(typeCLine1, &chocolate, sizeof(chocolate), 0);
				pthread_mutex_lock(&flagC1_mutex);
				flagCLine1=1;
				pthread_mutex_unlock(&flagC1_mutex); 
			}
				else if(flagCLine1==1){ 
				struct Chocolate chocolate;
				msgrcv(typeCLine1, &chocolate, sizeof(chocolate), 4 , 0);
				chocolate.type=1;
				chocolate.counter=2;
				chocolate.currentStep=5;
				sleep(minC_value + (rand() % (maxC_value - minC_value))); 
				msgsnd(Patch, &chocolate, sizeof(chocolate), 0);
				pthread_mutex_lock(&patchCounter_mutex);
				patch_counter=patch_counter+1;
				pthread_mutex_unlock(&patchCounter_mutex);
				//printf("send to patch C1 .....................................\n");
				//fflush(stdout);
			}
			
		}
	}
	}
}

void inOrderEmployeeC2(){
	pthread_t thread;
	thread=pthread_self();
	struct Chocolate chocolate;
	while(1){
	pthread_mutex_lock(&pause_mutex);
	int pauseCond=pauseCondition;
	pthread_mutex_unlock(&pause_mutex);
	if (pauseCond==0){
	pthread_mutex_lock(&typeC_mutex);
		strcpy(typeCstatues,"Runing");
		pthread_mutex_unlock(&typeC_mutex);
		sleep(1);
		if (pthread_equal(thread,threadTypeCEmployees[2][1]) || pthread_equal(thread,threadTypeCEmployees[2][2])|| pthread_equal(thread,threadTypeCEmployees[2][3])){
			if (pthread_equal(thread,threadTypeCEmployees[2][1])){
				chocolate.type=1;
				strcpy(chocolate.chocolateType,"C");
				for (int i=0; i<employeeCInAnyOrder ;i++){
					chocolate.stepTypeC[i]=0;
				}
				chocolate.counter=0;
				chocolate.currentStep=1;
				sleep(minC_value + (rand() % (maxC_value - minC_value))); 
				msgsnd(typeCLine2, &chocolate, sizeof(chocolate), 0);
			}else if (pthread_equal(thread,threadTypeCEmployees[2][2])){
				msgrcv(typeCLine2, &chocolate, sizeof(chocolate), 1 , 0);
				chocolate.type=2;
				strcpy(chocolate.chocolateType,"C");
				for (int i=0; i<employeeCInAnyOrder ;i++){
					chocolate.stepTypeC[i]=0;
				}
				chocolate.counter=0;
				chocolate.currentStep=2;
				sleep(minC_value + (rand() % (maxC_value - minC_value))); 
				msgsnd(typeCLine2, &chocolate, sizeof(chocolate), 0);
			}else if (pthread_equal(thread,threadTypeCEmployees[2][3])){
				msgrcv(typeCLine2, &chocolate, sizeof(chocolate), 2 , 0);
				chocolate.type=3;
				strcpy(chocolate.chocolateType,"C");
				for (int i=0; i<employeeCInAnyOrder ;i++){
					chocolate.stepTypeC[i]=0;
				}
				chocolate.counter=0;
				chocolate.currentStep=3;
				sleep(minC_value + (rand() % (maxC_value - minC_value)));
				
				pthread_mutex_lock(&flagC2_mutex);
				flagCLine2=0;
				pthread_mutex_unlock(&flagC2_mutex); 
				
				msgsnd(typeCLine2, &chocolate, sizeof(chocolate), 0);
			}	
		}	
	}
	}
}

void inAnyOrderEmployeeC2(int *line){
	pthread_t thread;
	thread=pthread_self();
	while(1){
	pthread_mutex_lock(&pause_mutex);
	int pauseCond=pauseCondition;
	pthread_mutex_unlock(&pause_mutex);
	if (pauseCond==0){
	pthread_mutex_lock(&typeC_mutex);
		strcpy(typeCstatues,"Runing");
		pthread_mutex_unlock(&typeC_mutex);
	sleep(1);
		if (pthread_equal(thread,threadTypeCEmployees[2][4]) || pthread_equal(thread,threadTypeCEmployees[2][5])){
			if(flagCLine2==0){ 
			
				struct Chocolate chocolate;
				msgrcv(typeCLine2, &chocolate, sizeof(chocolate), 3 , 0);
				chocolate.type=4;
				chocolate.counter=1;
				chocolate.currentStep=4;
				sleep(minC_value + (rand() % (maxC_value - minC_value))); 
				msgsnd(typeCLine2, &chocolate, sizeof(chocolate), 0);
				pthread_mutex_lock(&flagC2_mutex);
				flagCLine2=1;
				pthread_mutex_unlock(&flagC2_mutex); 
				
		}else if(flagCLine2==1){
				struct Chocolate chocolate;
				msgrcv(typeCLine2, &chocolate, sizeof(chocolate), 4 , 0);
				chocolate.type=1;
				chocolate.counter=2;
				chocolate.currentStep=5;
				sleep(minC_value + (rand() % (maxC_value - minC_value))); 
				msgsnd(Patch, &chocolate, sizeof(chocolate), 0);
				pthread_mutex_lock(&patchCounter_mutex);
				patch_counter=patch_counter+1;
				pthread_mutex_unlock(&patchCounter_mutex);
				//printf("send to patch C2 .....................................\n");
				//fflush(stdout);
			} 
		
		}
	}
	}
}

void patchThread(){
	  struct Chocolate chocolate;
	  pthread_t thread;
	  thread=pthread_self();
	  while(1){
	  		pthread_mutex_lock(&patchCounter_mutex);
			int counterOfPatch=patch_counter;
			pthread_mutex_unlock(&patchCounter_mutex);
			if (counterOfPatch %10 == 0  ){
				if (pthread_equal(thread,patchThreadid[0])){
					msgrcv(Patch, &chocolate, sizeof(chocolate), 1 , 0);
					//printf("type : %s\n",chocolate.chocolateType);
					//fflush(stdout);
					chocolate.type=1;
					msgsnd(printDateQueue, &chocolate, sizeof(chocolate), 0);
					
					
				}
				else if (pthread_equal(thread,patchThreadid[1])){
			  		msgrcv(Patch, &chocolate, sizeof(chocolate), 2 , 0);
					//printf("type : %s\n",chocolate.chocolateType);
					//fflush(stdout);
					chocolate.type=1;
					msgsnd(printDateQueue, &chocolate, sizeof(chocolate), 0);
				}
			}	
	  }
}

void printingExprestionThread(){
	struct Chocolate chocolate;		
	while(1){
	pthread_mutex_lock(&pause_mutex);
	int pauseCond=pauseCondition;
	pthread_mutex_unlock(&pause_mutex);
	//if (pauseCond==0){
		msgrcv(printDateQueue, &chocolate, sizeof(chocolate), 1 , 0);
		sleep(expiration_date_time);
		//printf("Print Exprestion Date Thread %s \n",chocolate.chocolateType);
		msgsnd(printDateDone, &chocolate, sizeof(chocolate), 0);
	//}
	}
}

void collectingTypeThread(){
	struct Chocolate chocolate;		
	while(1){
		msgrcv(printDateDone, &chocolate, sizeof(chocolate), 1 , 0);
		//printf("the type from collecting type thread is %s \n",chocolate.chocolateType);
		//fflush(stdout);
		if (strcmp(chocolate.chocolateType,"A")==0 ){
			msgsnd(typeAContainer, &chocolate, sizeof(chocolate), 0);
		}
		else if (strcmp(chocolate.chocolateType,"B")==0 ){
			msgsnd(typeBContainer, &chocolate, sizeof(chocolate), 0);
		}
		else if (strcmp(chocolate.chocolateType,"C")==0 ){
			msgsnd(typeCContainer, &chocolate, sizeof(chocolate), 0);
		} 
	}
}

void prepareAndFillCarton(){
	pthread_t thread;
	thread=pthread_self();
	struct Chocolate chocolate;
	struct Carton carton;
	while(1){
		if (pthread_equal(thread,prepareAndFillCartonId[0])){
			int cartonA;
			msgrcv(typeAContainer, &chocolate, sizeof(chocolate), 1 , 0);
			pthread_mutex_lock(&counterTypeA_mutex);
			counterTypeA=counterTypeA+1;
			int counterA=counterTypeA;
			pthread_mutex_unlock(&counterTypeA_mutex);
			carton.chocolateCarton[counterA%chocolatePerCarton]=chocolate;
			if (counterA % chocolatePerCarton==0){
				pthread_mutex_lock(&cartonTypeA_mutex);
				cartonTypeA=cartonTypeA+1;
				cartonA=cartonTypeA;
				pthread_mutex_unlock(&cartonTypeA_mutex);
				pthread_mutex_lock(&carton_mutex);
				cartonNumber=cartonNumber+1;
				int cartonN=cartonNumber;
				pthread_mutex_unlock(&carton_mutex);
				if (cartonN == max_storage_area){
					pthread_mutex_lock(&pause_mutex);
					pauseCondition=1;
					
					//printf("---------------------------------------------------------------------Pause\n");
					//fflush(stdout);
					pthread_mutex_unlock(&pause_mutex);
					pthread_mutex_lock(&typeA_mutex);
					strcpy(typeAstatues,"Pause");
					pthread_mutex_unlock(&typeA_mutex);
					pthread_mutex_lock(&typeC_mutex);
					strcpy(typeCstatues,"Pause");
					pthread_mutex_unlock(&typeC_mutex);
					pthread_mutex_lock(&typeB_mutex);
					strcpy(typeBstatues,"Pause");
					pthread_mutex_unlock(&typeB_mutex);
				}
				else if (cartonN < min_storage_area){
					pthread_mutex_lock(&pause_mutex);
					pauseCondition=0;
					pthread_mutex_unlock(&pause_mutex);
					pthread_mutex_lock(&typeA_mutex);
					strcpy(typeAstatues,"Runing");
					pthread_mutex_unlock(&typeA_mutex);
					pthread_mutex_lock(&typeC_mutex);
					strcpy(typeCstatues,"Runing");
					pthread_mutex_unlock(&typeC_mutex);
					pthread_mutex_lock(&typeB_mutex);
					strcpy(typeBstatues,"Runing");
					pthread_mutex_unlock(&typeB_mutex);
				}
				carton.type=1;
				strcpy(carton.boxType,"A");
				msgsnd(cartonBoxes, &carton, sizeof(carton), 0);
				//printf("carton type A %d\n",cartonA);
				//fflush(stdout);
			}
			//printf("counter of type A %d\n",counterTypeA);
			//fflush(stdout);
		}
		else if (pthread_equal(thread,prepareAndFillCartonId[1])){
			int cartonB;
			msgrcv(typeBContainer, &chocolate, sizeof(chocolate), 1 , 0);
			pthread_mutex_lock(&counterTypeB_mutex);
			counterTypeB=counterTypeB+1;
			int counterB=counterTypeB;
			pthread_mutex_unlock(&counterTypeB_mutex);
			carton.chocolateCarton[counterB%chocolatePerCarton]=chocolate;
			if (counterB %chocolatePerCarton ==0){
				pthread_mutex_lock(&cartonTypeB_mutex);
				cartonTypeB=cartonTypeB+1;
				cartonB=cartonTypeB;
				pthread_mutex_unlock(&cartonTypeB_mutex);
				pthread_mutex_lock(&carton_mutex);
				cartonNumber=cartonNumber+1;
				int cartonN=cartonNumber;
				pthread_mutex_unlock(&carton_mutex);
				if (cartonN == max_storage_area){
					pthread_mutex_lock(&pause_mutex);
					pauseCondition=1;
					//printf("-----------------------------------------------------------------------------Pause\n");
					//fflush(stdout);
					pthread_mutex_unlock(&pause_mutex);
				}
				else if (cartonN < min_storage_area){
					pthread_mutex_lock(&pause_mutex);
					pauseCondition=0;
					pthread_mutex_unlock(&pause_mutex);
				}
				carton.type=1;
				strcpy(carton.boxType,"B");
				msgsnd(cartonBoxes, &carton, sizeof(carton), 0);
				//printf("carton type B %d\n",cartonB);
				//fflush(stdout);
			}
			//printf("counter of type B %d\n",counterTypeB);
			//fflush(stdout);
		}
		else if (pthread_equal(thread,prepareAndFillCartonId[2])){
			int cartonC;
			msgrcv(typeCContainer, &chocolate, sizeof(chocolate), 1 , 0);
			pthread_mutex_lock(&counterTypeC_mutex);
			counterTypeC=counterTypeC+1;
			int counterC=counterTypeC;
			pthread_mutex_unlock(&counterTypeC_mutex);
			carton.chocolateCarton[counterC%chocolatePerCarton]=chocolate;
			if (counterC %chocolatePerCarton ==0 ){
				pthread_mutex_lock(&cartonTypeC_mutex);
				cartonTypeC=cartonTypeC+1;
				cartonC=cartonTypeC;
				pthread_mutex_unlock(&cartonTypeC_mutex);
				pthread_mutex_lock(&carton_mutex);
				cartonNumber=cartonNumber+1;
				int cartonN=cartonNumber;
				pthread_mutex_unlock(&carton_mutex);
				if (cartonN == max_storage_area){
					pthread_mutex_lock(&pause_mutex);
					pauseCondition=1;
					//printf("------------------------------------------------------------------------------------------Pause\n");
					//fflush(stdout);
					pthread_mutex_unlock(&pause_mutex);
				}
				else if (cartonN < min_storage_area){
					pthread_mutex_lock(&pause_mutex);
					pauseCondition=0;
					pthread_mutex_unlock(&pause_mutex);
				}
				carton.type=1;
				strcpy(carton.boxType,"C");
				msgsnd(cartonBoxes, &carton, sizeof(carton), 0);
				//printf("carton type C %d\n",cartonC);
				//fflush(stdout);
			}
			//printf("counter of type C %d\n",counterTypeC);
			//fflush(stdout);
		}
	}
}

void storageAreaThread(){
	struct Carton carton;
	while(1){
		msgrcv(cartonBoxes, &carton, sizeof(carton), 1 , 0);
		//printf("type of carton in storage area %s \n",carton.boxType);
		//fflush(stdout);
		sleep(absent_employee_time);
		if (strcmp(carton.boxType,"A")==0){
			carton.type=1;
		}else if (strcmp(carton.boxType,"B")==0){
			carton.type=2;
		}else if (strcmp(carton.boxType,"C")==0){
			carton.type=3;
		}
		msgsnd(storageArea, &carton, sizeof(carton), 0);
	}
}

void loadingEmployeeThread(){
	struct Carton carton;
	while(1){
	pthread_mutex_lock(&counterATruck_mutex);
	int counter_Atruck=counterATruck;
	pthread_mutex_unlock(&counterATruck_mutex);
	pthread_mutex_lock(&counterBTruck_mutex);
	int counter_Btruck=counterBTruck;
	pthread_mutex_unlock(&counterBTruck_mutex);
	pthread_mutex_lock(&counterCTruck_mutex);
	int counter_Ctruck=counterCTruck;
	pthread_mutex_unlock(&counterCTruck_mutex);
	
	//if (counter_Atruck% num_of_typeA < num_of_typeA){
		msgrcv(storageArea, &carton, sizeof(carton), 1 , 0);
		pthread_mutex_lock(&counterATruck_mutex);
		counterATruck=counterATruck+1;
		pthread_mutex_unlock(&counterATruck_mutex);
		carton.type=1;
		msgsnd(truck, &carton, sizeof(carton), 0);
	//}
	//if (counter_Btruck%num_of_typeB < num_of_typeB){
		msgrcv(storageArea, &carton, sizeof(carton), 2 , 0);
		pthread_mutex_lock(&counterBTruck_mutex);
		counterBTruck=counterBTruck+1;
		pthread_mutex_unlock(&counterBTruck_mutex);
		carton.type=2;
		msgsnd(truck, &carton, sizeof(carton), 0);
	//}
	//if (counter_Ctruck%num_of_typeC  < num_of_typeC ){
		msgrcv(storageArea, &carton, sizeof(carton), 3 , 0);
		pthread_mutex_lock(&counterCTruck_mutex);
		counter_Ctruck=counterCTruck+1;
		pthread_mutex_unlock(&counterCTruck_mutex);
		carton.type=3;
		msgsnd(truck, &carton, sizeof(carton), 0);
	//}
	}
}

void truckThread(){
	pthread_t thread;
	thread=pthread_self();
	struct Carton carton;
	//while(1){
		for (int i=0; i<num_of_typeA ;i++){
			msgrcv(truck, &carton, sizeof(carton), 1, 0);
			pthread_mutex_lock(&carton_mutex);
			cartonNumber=cartonNumber-1;
			pthread_mutex_unlock(&carton_mutex);
		}
		for (int i=0; i<num_of_typeB ;i++){
			msgrcv(truck, &carton, sizeof(carton), 2, 0);
			pthread_mutex_lock(&carton_mutex);
			cartonNumber=cartonNumber-1;
			pthread_mutex_unlock(&carton_mutex);
		}
		for (int i=0; i<num_of_typeA ;i++){
			msgrcv(truck, &carton, sizeof(carton), 3, 0);
			pthread_mutex_lock(&carton_mutex);
			cartonNumber=cartonNumber-1;
			pthread_mutex_unlock(&carton_mutex);
		}
		pthread_mutex_lock(&truckStatues_mutex);
		strcpy(truckStatues,"Shipping");
		pthread_mutex_unlock(&truckStatues_mutex);
		//printf("Truck is go to shipping *********************************************************************\n");
		//fflush(stdout);	
		sleep(truck_sleep);
	//}
}



void read_configuration(char *file_name){ 
    char read[50];
    FILE *fptr;
    fptr = fopen(file_name,"r"); 
    if (fptr == NULL){
        printf("\033[0;31m"); // set the color to red 
        perror("Error while opening the file.\n");
        printf("\033[0m");// reset the color to the default
        exit(-1);
    }  
    while (fgets(read, sizeof(read), fptr)) {
        char *token = strtok(read," ");
        if(strcmp(token, "MAXA_VALUE") == 0){
       	    pthread_mutex_lock(&timeA_mutex);
            maxA_value = atoi(strtok(NULL,"\n"));
            pthread_mutex_unlock(&timeA_mutex);
        }else if (strcmp(token, "MINA_VALUE") == 0){
            pthread_mutex_lock(&timeA_mutex);
            minA_value = atoi(strtok(NULL,"\n"));
            pthread_mutex_unlock(&timeA_mutex);
        }else if (strcmp(token, "MAXB_VALUE") == 0){
			pthread_mutex_lock(&timeB_mutex);
            maxB_value = atoi(strtok(NULL,"\n"));
			pthread_mutex_unlock(&timeB_mutex);
        }else if (strcmp(token, "MINB_VALUE") == 0){
			pthread_mutex_lock(&timeB_mutex);
            minB_value = atoi(strtok(NULL,"\n"));
			pthread_mutex_unlock(&timeB_mutex);
        }else if (strcmp(token, "MAXC_VALUE") == 0){
            maxC_value = atoi(strtok(NULL,"\n"));
        }else if (strcmp(token, "MINC_VALUE") == 0){
            minC_value = atoi(strtok(NULL,"\n"));
        }else if (strcmp(token, "EXPIRATION_DATE_TIME") == 0){
            expiration_date_time = atoi(strtok(NULL,"\n"));
        }else if (strcmp(token, "ABSENT_EMPLOYEE_TIME") == 0){
            absent_employee_time = atoi(strtok(NULL,"\n"));
        }else if (strcmp(token, "MAX_STORAGE_AREA") == 0){
            max_storage_area = atoi(strtok(NULL,"\n"));
        }else if (strcmp(token, "MIN_STORAGE_AREA") == 0){
            min_storage_area = atoi(strtok(NULL,"\n"));
        }else if (strcmp(token, "NUM_OF_TYPEA") == 0){
            num_of_typeA = atoi(strtok(NULL,"\n"));
        }else if (strcmp(token, "NUM_OF_TYPEB") == 0){
	num_of_typeB = atoi(strtok(NULL,"\n"));
	}else if (strcmp(token, "NUM_OF_TYPEC") == 0){
	num_of_typeC = atoi(strtok(NULL,"\n"));
	}else if (strcmp(token, "TRUCK_SLEEP") == 0){
	truck_sleep = atoi(strtok(NULL,"\n"));
	}else if (strcmp(token, "BOX_TYPEA") == 0){
	box_typeA = atoi(strtok(NULL,"\n"));
	}else if (strcmp(token, "BOX_TYPEB") == 0){
	box_typeB = atoi(strtok(NULL,"\n"));
	}else if (strcmp(token, "BOX_TYPEC") == 0){
	box_typeC = atoi(strtok(NULL,"\n"));
	}else if (strcmp(token, "SIMULATION_TIME") == 0){
	simulation_time = atoi(strtok(NULL,"\n"));
	}   
    } 
    if(fclose(fptr)){
        exit(-1);
    }
}


