gcc openGl.c -o openGl -lGL -lGLU -lglut
gcc chocolate.c -o chocolate  -lpthread
./chocolate configuration.txt
