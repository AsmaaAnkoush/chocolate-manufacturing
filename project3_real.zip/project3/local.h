#ifndef __LOCAL_H_
#define __LOCAL_H_

/*
 * Common header file
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/shm.h>
#include <sys/msg.h>
#include <sys/ipc.h>
#include <pthread.h>
#include <stdbool.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <time.h>
#include <signal.h>
#include <errno.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <pthread.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <semaphore.h>
#include <sys/types.h>
#include <linux/stat.h>

/*Colors*/

#define ORIGINAL "\x1B[0m"
#define RED_COLOR "\x1B[31m"
#define GREEN_COLOR "\x1B[32m"
#define YELLOW_COLOR "\x1B[33m"
#define BLUE_COLOR "\x1B[34m"
#define PURPLE_COLOR "\x1B[35m"
#define CYAN_COLOR "\x1B[36m"
#define WHITE_COLOR "\x1B[37m" 
#define typeAmanfactorLines 3
#define typeBmanfactorLines 2
#define typeCmanfactureLines 2
#define employeeANumbers 8
#define employeeAInAnyOrder 4
#define employeeCInAnyOrder 2
#define employeeBNumbers 6
#define employeeCNumbers 5
#define patchEmployee 2
#define collectingTypeEmployee 3
#define prepareAndFillCartonEmployees 3
#define chocolatePerCarton 2
#define storageAreaEmployee 2
#define loadingEmployee 2
#define truckNumber 3

int maxA_value;
int minA_value;
int maxB_value;
int minB_value;
int maxC_value;
int minC_value;
int expiration_date_time;
int absent_employee_time;
int max_storage_area;
int min_storage_area;
int num_of_typeA;
int num_of_typeB;
int num_of_typeC;
int box_typeA;
int box_typeB;
int box_typeC;
int simulation_time;
int truck_sleep;
int pid;
int parentPid;

int r1,r2;
int patch_counter=0;
int flagALine1=0;
int flagALine2=0;
int flagALine3=0;
int flagCLine1=0;
int flagCLine2=0;
int counterTypeA=0;
int counterTypeB=0;
int counterTypeC=0;
int cartonTypeA=0;
int cartonTypeB=0;
int cartonTypeC=0;
int cartonNumber =0;
int pauseCondition=0;
int counterATruck=0;
int counterBTruck=0;
int counterCTruck=0;
int truckOrder=0;
char typeAstatues[10]="Stop";
char typeBstatues[10]="Stop";
char typeCstatues[10]="Stop";
char truckStatues[10]="Waiting";
void typeAThread();
void typeBThread();
void printingExprestionThread();
void inOrderEmployeeA1(int *line);
void inAnyOrderEmployeeA1(int *line);
void inOrderEmployeeA2(int *line);
void inAnyOrderEmployeeA2(int *line);
void inOrderEmployeeA3(int *line);
void inAnyOrderEmployeeA3(int *line);
void read_configuration(char *);
void typeBThread(int *line_number);
void inOrderEmployeeB1(int *line);
void inOrderEmployeeB2(int *line);
void typeCThread(int *line_number);
void inOrderEmployeeC1();
void inAnyOrderEmployeeC1(int *line);
void inOrderEmployeeC2();
void inAnyOrderEmployeeC2(int *line);
void patchThread();
void collectingTypeThread();
void prepareAndFillCarton();
void storageAreaThread();
void loadingEmployeeThread();
void truckThread();
void *print_msg(void *);
void terminationThread();
void forkOpenGl( );

int counterTypeAEmployeeLine1[employeeANumbers];
int counterTypeAEmployeeLine2[employeeANumbers];
int counterTypeAEmployeeLine3[employeeANumbers];
int counterTypeBEmployeeLine1[employeeBNumbers];
int counterTypeBEmployeeLine2[employeeBNumbers];
//struct timespec start, finish;
struct timespec start, finish,check;

pthread_t threadidTypeA[typeAmanfactorLines];
pthread_t threadidTypeB[typeBmanfactorLines];
pthread_t threadidTypeC[typeCmanfactureLines];
pthread_t patchThreadid[patchEmployee];
pthread_t collectingTypeid[collectingTypeEmployee];
pthread_t prepareAndFillCartonId[prepareAndFillCartonEmployees];
pthread_t threadTypeAEmployees[typeAmanfactorLines][employeeANumbers];
pthread_t threadTypeBEmployees[typeBmanfactorLines][employeeBNumbers];
pthread_t threadTypeCEmployees[typeCmanfactureLines][employeeCNumbers];
pthread_t storageAreaId[storageAreaEmployee];
pthread_t loadingEmployeeId[loadingEmployee];
pthread_t truckId[truckNumber];
pthread_t printingExprestionDate;
pthread_t termination;
pthread_t thread_console;
pthread_mutex_t typeALine1_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t typeALine2_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t typeALine3_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t typeBLine1_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t typeBLine2_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t typeA_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t typeB_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t typeC_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t flagA1_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t flagA2_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t flagA3_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t timeA_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t timeB_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t flagC1_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t flagC2_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t patchCounter_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t counterTypeA_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t counterTypeB_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t counterTypeC_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t cartonTypeA_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t cartonTypeB_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t cartonTypeC_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t carton_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t pause_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t counterATruck_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t counterBTruck_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t counterCTruck_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t console_mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t truckStatues_mutex=PTHREAD_MUTEX_INITIALIZER;

key_t typeALine1Key;
int typeALine1;

key_t typeALine2Key;
int typeALine2;

key_t typeALine3Key;
int typeALine3;

key_t typeBLine1Key;
int typeBLine1;

key_t typeBLine2Key;
int typeBLine2;

key_t typeCLine1Key;
int typeCLine1;

key_t typeCLine2Key;
int typeCLine2;

key_t PatchKey;
int Patch;

key_t printDateQueueKey;
int printDateQueue;

key_t printDateDoneKey;
int printDateDone;

key_t typeAContainerKey;
int typeAContainer;

key_t typeBContainerKey;
int typeBContainer;

key_t typeCContainerKey;
int typeCContainer;

key_t cartonBoxesKey;
int cartonBoxes;

key_t storageAreaKey;
int storageArea;

key_t truckKey;
int truck;

struct Chocolate
{
	long type;
	char chocolateType[1];
	int counter;
	int stepTypeA[employeeAInAnyOrder];
	int stepTypeC[employeeCInAnyOrder];
	int currentStep;
	int previouesEmployeeStep;
}Chocolate;

struct Carton
{
	long type;
	struct Chocolate chocolateCarton[chocolatePerCarton];
	char boxType[1];
}Carton;


          

 //High intensty background

#define REDHB "\e[0;101m" 

#define WHTHB "\e[0;107m"

#define WHTB "\e[47m"

#define BLKB "\e[40m"



//Bold High intensty 

#define BHBLK "\e[1;90m"

#define BHRED "\e[1;91m"

#define BHGRN "\e[1;92m"

#define BHYEL "\e[1;93m"

#define BHBLU "\e[1;94m"

#define BHMAG "\e[1;95m"

#define BHCYN "\e[1;96m"

#define BHWHT "\e[1;97m"

#define SHM_KEY 0x3000 
#define TOTAL_STEPS 10
#define TOTAL_LINES 10
#define PRODUCT_BUFFER 10
#define LAPTOPS_PER_CARTONS 10
#define TRUCK_WAITING 0
#define TRUCK_LOADING 1
#define TRUCK_ON_TRIP 2
#define LINE_STATUS_RUNNING 0
#define LINE_STATUS_SUSPENDED 1
#define SOLD_LAPTOPS 5
#define MIN_LAPTOPS_PER_PROFIT 10
#endif

