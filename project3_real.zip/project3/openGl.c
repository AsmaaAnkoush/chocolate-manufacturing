#include <stdlib.h>
#include <math.h>
#include <limits.h>
#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <math.h>
void display();
void reshape(int,int);
void timer();
void timer2();
void timer3();
void timer4();
void timer5();
void timerline();
void initGL();



    
// Global variable
GLfloat angle = 0.0f; // Current rotational angle of the shapes
GLfloat angle2 = 0.0f; // Current rotational angle of the shapes
float x_position =-1.0f;
float x_position2 =-0.1f;
float x_position3 =-0.1f;
float x_position4 =0.8f;
float z_position4 =0.3f;
float y_position =0.32f;
float x_pos= -0.8f;
int state = 1; 
int state1 = 1; 
int state2 = 1; 
int flag = 1; 

static int font_index=0;

void print_bitmap_string(/*void* font,*/ char* s)
{
      while (*s) {
         glutBitmapCharacter( GLUT_BITMAP_HELVETICA_18, *s);
         s++;
      }
  
}

/* Initialize OpenGL Graphics */
void initGL() {
    // Set "clearing" or background color
 glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // Black and opaque
}

/* Called back when there is no other event to be handled */
void idle() {
    glutPostRedisplay(); // Post a re-paint request to activate display()
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_LINES);
    glColor3f(0, 0, 1);
    glVertex3f(0.4f, 1.0f, 0.0f);
    glEnd();
    
  
  
    glBegin(GL_LINES);
        //glColor3f(0.0, 0.0,1);
        
        glVertex2f(-1.0,0.6);
        glVertex2f(-0.3, 0.6);  
        
         glVertex2f(-1.0, 0.50);
         glVertex2f(-0.3, 0.50); 
         
         
        glVertex2f(-1, 0.40);
         glVertex2f(-0.3, 0.40);   

       
        glColor3f(1.0, 0.0, 1.0); //purpule 
        
        glVertex2f(-1, 0.2);
        glVertex2f(-0.3, 0.2); 
        
         
        glVertex2f(-1,0.1);
        glVertex2f(-0.3, 0.1); 
        
        
   
               
        glColor3f(0.0, 0.0, 0.0); //purpule 
        
        glVertex2f(-1, -0.2);
        glVertex2f(-0.3, -0.2); 
        
         
        glVertex2f(-1,-0.3);
        glVertex2f(-0.3,- 0.3); 
        
       
        glEnd();
        
        
        glPointSize(8);
         glBegin(GL_POINTS);
    glColor3f(0.0, 0.0,1); //blue lineA
    glVertex3f(-1, 0.4f, 0.0f);
    glVertex3f(-0.9, 0.4f, 0.0f);
    glVertex3f(-0.8, 0.4f, 0.0f);
     glVertex3f(-0.7, 0.4f, 0.0f);
     glVertex3f(-0.6, 0.4f, 0.0f);
      glVertex3f(-0.5, 0.4f, 0.0f);
    glVertex3f(-0.4, 0.4f, 0.0f);
     glVertex3f(-0.3, 0.4f, 0.0f);
    glEnd();
    
    
     // glPushMatrix();
    //glTranslatef(-0.1f, 0.1f, 0.1f); // Translate
   //glRotatef(angle, 0.2f, .0f, 0.0f);
  glBegin(GL_POINTS);
     glVertex3f(-0.9, 0.4f, 0.0f);
   glEnd();
  //glPopMatrix(); // Restore the model-view matrix
        
  glBegin(GL_POINTS);
    glColor3f(0.0, 0.0,1); //blue lineA 
    glVertex3f(-1, 0.6f, 0.0f);
     glVertex3f(-0.9, 0.6f, 0.0f);
     glVertex3f(-0.8, 0.6f, 0.0f);
     glVertex3f(-0.7, 0.6f, 0.0f);
     glVertex3f(-0.6, 0.6f, 0.0f);
      glVertex3f(-0.5, 0.6f, 0.0f);
    glVertex3f(-0.4, 0.6f, 0.0f);
     glVertex3f(-0.3, 0.6f, 0.0f);
    glEnd();
        
 glBegin(GL_POINTS);
    glColor3f(0.0, 0.0,1); //blue lineA 
    glVertex3f(-1, 0.5f, 0.0f);
     glVertex3f(-0.9, 0.5f, 0.0f);
    glVertex3f(-0.8, 0.5f, 0.0f);
     glVertex3f(-0.7, 0.5f, 0.0f);
     glVertex3f(-0.6, 0.5f, 0.0f);
      glVertex3f(-0.5, 0.5f, 0.0f);
    glVertex3f(-0.4, 0.5f, 0.0f);
     glVertex3f(-0.3, 0.5f, 0.0f);
    glEnd();
    
    
     glBegin(GL_POINTS);
    glColor3f(0.0, 1.0, 0.0); //green lineB
    glVertex3f(-1, 0.2f, 0.0f);
     glVertex3f(-0.9, 0.2f, 0.0f);
  glVertex3f(-0.8, 0.2f, 0.0f);
    glVertex3f(-0.7, 0.2f, 0.0f);
     glVertex3f(-0.6, 0.2f, 0.0f);
     glVertex3f(-0.5, 0.2f, 0.0f);
    glEnd();
        
         
     glBegin(GL_POINTS);
    glColor3f(0.0, 1.0, 0.0); //green lineB
    glVertex3f(-1, 0.1f, 0.0f);
     glVertex3f(-0.9, 0.1f, 0.0f);
    glVertex3f(-0.8, 0.1, 0.0f);
     glVertex3f(-0.7, 0.1f, 0.0f);
     glVertex3f(-0.6, 0.1f, 0.0f);
      glVertex3f(-0.5, 0.1f, 0.0f);
    glEnd();
    
    
  
    
    glBegin(GL_POINTS);
    glColor3f(0.0, 0.0, 0.0); //black  linEC
    glVertex3f(-1, -0.2f, 0.0f);
     glVertex3f(-0.9, -0.2f, 0.0f);
    glVertex3f(-0.8, -0.2, 0.0f);
     glVertex3f(-0.7, -0.2f, 0.0f);
     glVertex3f(-0.6, -0.2f, 0.0f);

    glEnd();
    
    
     glBegin(GL_POINTS);
    glColor3f(0.0, 0.0, 0.0); //black  linEC
    glVertex3f(-1, -0.3f, 0.0f);
     glVertex3f(-0.9, -0.3f, 0.0f);
    glVertex3f(-0.8, -0.3f, 0.0f);
     glVertex3f(-0.7, -0.3f, 0.0f);
     glVertex3f(-0.6, -0.3f, 0.0f);

  glEnd();
  
  //SALAT
         glBegin(GL_LINES);
        glColor3f(0.0, 0.0,1);
        
        glVertex2f(-0.2, 0.4);
        glVertex2f(-0.2, 0.25);  
       glVertex2f(-0.2, 0.25);  
        glVertex2f(0, 0.25);
        glVertex2f(0, 0.25);
       glVertex2f(0, 0.4);
       
        glEnd();
  //SALAT
  
         glBegin(GL_LINES);
        glColor3f(0.0, 0.0,1);
        
        glVertex2f(-0.2, 0.1);
        glVertex2f(-0.2, -0.1); 
         
       glVertex2f(-0.2, -0.1);  
        glVertex2f(0, -0.10);
        
        glVertex2f(0,-0.10);
        glVertex2f(0, 0.1);
       
        glEnd();
        
       //SALAT
        
         glBegin(GL_LINES);
        glColor3f(0.0, 0.0,1);
        
        glVertex2f(-0.2, -0.3);
        glVertex2f(-0.2, -0.45); 
         
       glVertex2f(-0.2, -0.45);  
        glVertex2f(0,-0.45);
        
        glVertex2f(0,-0.45);
        glVertex2f(0, -0.3);
        

       
        glEnd();
        

   	 glBegin(GL_POINTS);
    glColor3f(1.0, 1.0, 0.0); //white
   	 glVertex3f(-0.1f,-0.4f, 0.0f); 
   	 glVertex3f(-0.1f,-0.35f, 0.0f);  
   	  glVertex3f(-0.16f,-0.4f, 0.0f); 
   	 glVertex3f(-0.16f,-0.35f, 0.0f);  
   	 glVertex3f(-.06f,-0.4f, 0.0f); 
   	 glVertex3f(-0.06f,-0.35f, 0.0f); 
   	  
    	glEnd();

    	 glBegin(GL_POINTS);
    	 glColor3f(0.5, 0.0, 1.0); //pyrpue
   	 glVertex3f(-0.1f,0.0f, 0.0f); 
   	 glVertex3f(-0.1f,0.05f, 0.0f);  
   	  glVertex3f(-0.16f,0.0f, 0.0f); 
   	 glVertex3f(-0.16f,0.05f, 0.0f);  
   	 glVertex3f(-.06f,0.0f, 0.0f); 
   	 glVertex3f(-0.06f,0.05f, 0.0f); 
   
  	  
    	glEnd();
    	 glBegin(GL_POINTS);
    	 glColor3f(1.0, 0.0, 0.0); //red
   	 glVertex3f(-0.1f,0.27f, 0.0f); 
   	 glVertex3f(-0.1f,0.32f, 0.0f);  
   	  glVertex3f(-0.16f,0.27f, 0.0f); 
   	 glVertex3f(-0.16f,0.32f, 0.0f);  
   	 glVertex3f(-.06f,0.27f, 0.0f); 
   	 glVertex3f(-0.06f,0.32f, 0.0f); 
   	     	glEnd();
  
      	
      	 
  //LINE 8
         glBegin(GL_LINES);
        glColor3f(0.0, 0.0,1);  
        glVertex2f(0.0, 0.25);
        glVertex2f(0.4, 0);      
       glVertex2f(0, -0.1);  
       glVertex2f(0.4, 0);
        glVertex2f(0,-0.45);
      glVertex2f(0.4, 0);
        glEnd();
        
        
             glBegin(GL_POINTS);
             glVertex3f(0.46f,0.02f, 0.0f); 
             glColor3f(1.0, 0.0, 0.0); //red
             glVertex3f(0.51f,0.02f, 0.0f); 
             glColor3f(1.0, 1.0, 0.0); //yellow
             glVertex3f(0.56f,0.02f, 0.0f); 
             glColor3f(0.0, 0.0,1);  
             glVertex3f(0.61f,0.02f, 0.0f); 
              glColor3f(1.0, 0.0, 0.0); //red
             glVertex3f(0.66f,0.02f, 0.0f); 
   glColor3f(1.0, 1.0, 0.0); //yellow
             glVertex3f(0.71f,0.02f, 0.0f); 
             glEnd();
             
        
        
       glBegin(GL_POINTS);
     glColor3f(0.5, 0.0, 1.0); //blue
    glVertex3f(0.77, -0.15f, 0.0f);
     glColor3f(1.0, 0.0, 0.0); //red
    glVertex3f(0.77,-0.10f, 0.0f);
   glColor3f(1.0, 1.0, 0.0); //yellow
     glVertex3f(0.72, -0.15f, 0.0f);
     glColor3f(1.0, 0.0, 0.0); //red
    glVertex3f(0.72,-0.10f, 0.0f);
     glColor3f(0.5, 0.0, 1.0); //blue
     glVertex3f(0.82, -0.15f, 0.0f);
   glColor3f(1.0, 1.0, 0.0); //yellow
    glVertex3f(0.82,-0.10f, 0.0f);
    glColor3f(1.0, 0.0, 0.0); //red
     glVertex3f(0.87, -0.15f, 0.0f);
     glColor3f(1.0, 1.0, 0.0); //yellow
    glVertex3f(0.87,-0.10f, 0.0f);
     glColor3f(0.5, 0.0, 1.0); //blue
     glVertex3f(0.92, -0.15f, 0.0f);
     glColor3f(1.0, 0.0, 0.0); //red
    glVertex3f(0.97,-0.10f, 0.0f);
     glColor3f(0.5, 0.0, 1.0); //blue
     glVertex3f(1.02, -0.15f, 0.0f);
   glColor3f(1.0, 1.0, 0.0); //yellow
    glVertex3f(1.02,-0.10f, 0.0f);
 
    glEnd();
    
       
           glBegin(GL_LINES);
        glColor3f(0.0, 0.0,1);
         glVertex2f(0.4, 0); 
        glVertex2f(0.7, 0);
        
                glEnd();
         
                
        
           glBegin(GL_LINES);
        glColor3f(0.0, 0.0,1);
        
         glVertex2f(0.7, 0); 
        glVertex2f(0.7, -0.2);
        
        glVertex2f(0.7, -0.2);
        glVertex2f(1.1, -0.2);
        
        glVertex2f(1.1, -0.2);
        glVertex2f(1.1,0);
                glEnd();
         
       
  
  
         glBegin(GL_LINES);
        glColor3f(0.0, 0.0,1);
        
        glVertex2f(1.3,0.4);
        glVertex2f(1.3, 0.25);  
       glVertex2f(1.3, 0.25);  
        glVertex2f(1.6,0.25);
        glVertex2f(1.6,0.25);
        glVertex2f(1.6,0.4);
       
        glEnd();
  
    glBegin(GL_LINES);
        glColor3f(0.0, 0.0,1);
        
        glVertex2f(1.3,0.15);
        glVertex2f(1.3, 0.0);  
       glVertex2f(1.3, 0.0);  
        glVertex2f(1.6,0.0);
        glVertex2f(1.6,0.0);
        glVertex2f(1.6,0.15);
       
        glEnd();
  
  
   glBegin(GL_LINES);
        glColor3f(0.0, 0.0,1);
        
        glVertex2f(1.3,-.15);
        glVertex2f(1.3,-.3);  
       glVertex2f(1.3,-0.3); 
        glVertex2f(1.6,-0.3);
        glVertex2f(1.6,-0.3);
        glVertex2f(1.6,-.15);
       
        glEnd();
  
  	 glBegin(GL_POINTS);
   glColor3f(1.0, 1.0, 0.0); //yellow
   	 glVertex3f(1.32f,0.3f, 0.0f); 
   	 glVertex3f(1.32f,0.35f, 0.0f);  
   	  glVertex3f(1.38f,0.3f, 0.0f); 
   	 glVertex3f(1.38f,0.35f, 0.0f);  
   	 glVertex3f(1.44f,0.35f, 0.0f); 
   	 glVertex3f(1.44f,0.3f, 0.0f); 
   	  
    	glEnd();
    	 glBegin(GL_POINTS);
     glColor3f(0.5, 0.0, 1.0); //blue
    glVertex3f(1.32f,-0.25f, 0.0f); 
   	 glVertex3f(1.32f,-0.20f, 0.0f);  
   	  glVertex3f(1.38f,-0.25f, 0.0f); 
   	 glVertex3f(1.38f,-0.20f, 0.0f);  
   	 glVertex3f(1.44f,-0.25f, 0.0f); 
   	 glVertex3f(1.44f,-0.20f, 0.0f); 
   
  	  
    	glEnd();
    	 glBegin(GL_POINTS);
    	 glColor3f(1.0, 0.0, 0.0); //red
   	  glVertex3f(1.32f,0.05f, 0.0f); 
   	 glVertex3f(1.32f,0.1f, 0.0f);  
   	  glVertex3f(1.38f,0.05f, 0.0f); 
   	 glVertex3f(1.38f,0.1f, 0.0f);  
   	 glVertex3f(1.44f,0.05f, 0.0f); 
   	 glVertex3f(1.44f,0.1f, 0.0f);  
   	     	glEnd();
  

   glBegin(GL_POINTS);
    glColor3f(0.0, 0.0,1); //blue 

         glVertex3f(x_position, 0.4f, 0.0f);
    glEnd();
    
    
      glBegin(GL_POINTS);
    glColor3f(0.0, 0.0,1); //blue 
     glVertex3f(x_position, 0.6f, 0.0f);

    glEnd();


    glBegin(GL_POINTS);
    glColor3f(0.0, 0.0,1); //blue 
    glVertex3f(x_position, 0.5f, 0.0f);
    glEnd();
 	
 glBegin(GL_POINTS);
    glColor3f(0.0, 1.0, 0.0); //green 
    glVertex3f(x_position, 0.2f, 0.0f);
    glEnd();
 
 
  glBegin(GL_POINTS);
    glColor3f(0.0, 1.0, 0.0); //green 
     glVertex3f(x_position, 0.1f, 0.0f);
    glEnd();
    glBegin(GL_POINTS);
    glColor3f(0.0, 0.0, 0.0); //black  
     glVertex3f(x_position, -0.2f, 0.0f);
    glEnd();

 glBegin(GL_POINTS);
    glColor3f(0.0, 0.0, 0.0); //black 
        glVertex3f(x_position, -0.3f, 0.0f);
        glColor3f(1.0, 0.0, 0.0); //red
      //  glVertex3f(x_position3,y_position, 0.0f);
    glEnd();
   
   
   
   
  glBegin(GL_POINTS);
    glColor3f(1.0, 1.0, 0.0); //white
        glVertex3f(x_position2, -0.4f, 0.0f);
    glEnd();


  glBegin(GL_POINTS);
    	 glColor3f(0.5, 0.0, 1.0); //pyrpue
        glVertex3f(x_position2, 0.0f, 0.0f);
    glEnd();
    
    
      glBegin(GL_POINTS);
    	 glColor3f(1.0, 0.0, 0.0); //red
        glVertex3f(x_position2, 0.32f, 0.0f);
    glEnd();



 glBegin(GL_POINTS);
    	 glColor3f(1.0, 0.0, 0.0); //red
        glVertex3f(x_position4, -0.14f, 0.0f);
           glColor3f(0.5, 0.0, 1.0); //pyrpue
            glVertex3f(x_position4,-0.10f, 0.0f);
    glEnd();
    
    
     glBegin(GL_POINTS);
    	 glColor3f(1.0, 0.0, 0.0); //red
        //glVertex3f(x_position2+1.5,z_position4, 0.0f); 
    glEnd();

    

// Morab3             
    glBegin(GL_POLYGON);
    glColor3f(1.0f, 0.0f, 0.0f);   //red
    glVertex2f(2.0,0.8);
    glVertex2f(2.0,0.5);
    glVertex2f(2.3,0.5);
    glVertex2f(2.3,0.8);
    glEnd();
 // Morab3             
    glBegin(GL_POLYGON);
    glColor3f(0.0, 0.0,1); //blue 
    glVertex2f(2.3,0.65);
     glVertex2f(2.3,0.5);
    glVertex2f(2.4,0.5);
    glVertex2f(2.4,0.65);
    glEnd();
    
    
    
    
    // Morab3             
    glBegin(GL_POLYGON);
    glColor3f(1.0f, 0.0f, 0.0f);   //red
    glVertex2f(2.0,0.3);
    glVertex2f(2.0,0.0);
    glVertex2f(2.3,0.0);
    glVertex2f(2.3,0.3);
    glEnd();
 // Morab3             
    glBegin(GL_POLYGON);
    glColor3f(0.0, 0.0,1); //blue 
    glVertex2f(2.3,0.15);
     glVertex2f(2.3,0.0);
    glVertex2f(2.4,0.0);
    glVertex2f(2.4,0.15);
    glEnd();
    
    
   
        // Morab3             
    glBegin(GL_POLYGON);
    glColor3f(1.0f, 0.0f, 0.0f);   //red
    glVertex2f(2.0,-0.2);
    glVertex2f(2.0,-0.5);
    glVertex2f(2.3,-0.5);
    glVertex2f(2.3,-0.2);
    glEnd();
 // Morab3             
    glBegin(GL_POLYGON);
    glColor3f(0.0, 0.0,1); //blue 
    glVertex2f(2.3,-0.35);
     glVertex2f(2.3,-0.5);
    glVertex2f(2.4,-0.5);
    glVertex2f(2.4,-0.35);
    glEnd();
    
    
//al3jall

   glBegin(GL_POINTS);
        glPointSize(15);
        glColor3f(0, 0.0,0); //black
    glVertex3f(2.1, -0.5f, 0.0f);
    glVertex3f(2.3,-0.5f, 0.0f);
       glVertex3f(2.1, 0.0f, 0.0f);
    glVertex3f(2.3,0.0f, 0.0f);
     glVertex3f(2.1, 0.5f, 0.0f);
    glVertex3f(2.3,0.5f, 0.0f);
  
    glEnd();



//person 
  glBegin(GL_POINTS);
        glPointSize(15);
        glColor3f(0, 0.0,0); //black
    glVertex3f(1.0, -0.5f, 0.0f);
        glEnd();
 glBegin(GL_LINES);
        glColor3f(0.0, 0.0,0.0);  
        glVertex2f(1,-.5);
       glVertex2f(1,-.6);
        glEnd();
         glBegin(GL_LINES);
        glColor3f(0.0, 0.0,0.0); 
         
        glVertex2f(1,-.55);
        glVertex2f(0.97,-.6);
        glVertex2f(1,-.55);
        glVertex2f(1.03,-.6);
        
        glVertex2f(1,-.6);
       glVertex2f(0.97,-.65);
       glVertex2f(1,-.6);
       glVertex2f(1.03,-.65);
        glEnd();
        
        //person 
  glBegin(GL_POINTS);
        glPointSize(15);
        glColor3f(0, 0.0,0); //black
    glVertex3f(1.0, 0.4f, 0.0f);
        glEnd();
 glBegin(GL_LINES);
        glColor3f(0.0, 0.0,0.0);  
        glVertex2f(1,.4);
       glVertex2f(1,.3);
        glEnd();
         glBegin(GL_LINES);
        glColor3f(0.0, 0.0,0.0); 
         
        glVertex2f(1,.35);
        glVertex2f(0.97,.3);
        glVertex2f(1,.35);
        glVertex2f(1.03,.3);
        
        glVertex2f(1,.3);
       glVertex2f(0.97,.25);
       glVertex2f(1,.3);
       glVertex2f(1.03,.25);
        glEnd();
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

 //person 1
  glBegin(GL_POINTS);
        glPointSize(15);
        glColor3f(0, 0.0,0); //black
    glVertex3f(0.4, 0.3f, 0.0f);
        glEnd();
 glBegin(GL_LINES);
        glColor3f(0.0, 0.0,0.0);  
        glVertex2f(0.4,0.2);
       glVertex2f(0.4,0.3);
        glEnd();
         glBegin(GL_LINES);
        glColor3f(0.0, 0.0,0.0); 
         glVertex2f(0.4,0.25);
       glVertex2f(0.37,.23);
       glVertex2f(0.4,0.25);
       glVertex2f(0.43,.23);
       
        glVertex2f(0.4,.2);
        glVertex2f(0.37,.15);
        glVertex2f(0.4,.2);
        glVertex2f(0.43,0.15);
        
      
        glEnd();
   
    //person 2
  glBegin(GL_POINTS);
        glPointSize(15);
        glColor3f(0, 0.0,0); //black
    glVertex3f(0.4, -0.2f, 0.0f);
        glEnd();
 glBegin(GL_LINES);
        glColor3f(0.0, 0.0,0.0);  
        glVertex2f(0.4,-0.2);
       glVertex2f(0.4,-0.3);
        glEnd();
         glBegin(GL_LINES);
        glColor3f(0.0, 0.0,0.0); 
         glVertex2f(0.4,-0.25);
       glVertex2f(0.37,-.28);
       glVertex2f(0.4,-0.25);
       glVertex2f(0.43,-.28);
       
        glVertex2f(0.4,-.3);
        glVertex2f(0.37,-.35);
        glVertex2f(0.4,-.3);
        glVertex2f(0.43,-0.35);
      
        glEnd();
        
    //person 3 
  glBegin(GL_POINTS);
        glPointSize(15);
        glColor3f(0, 0.0,0); //black
    glVertex3f(1.8, -0.2f, 0.0f);
        glEnd();
 glBegin(GL_LINES);
        glColor3f(0.0, 0.0,0.0);  
        glVertex2f(1.8,-0.2);
       glVertex2f(1.8,-0.3);
        glEnd();
         glBegin(GL_LINES);
        glColor3f(0.0, 0.0,0.0); 
         glVertex2f(1.8,-0.25);
       glVertex2f(1.77,-.28);
       glVertex2f(1.8,-0.25);
       glVertex2f(1.83,-.28);
       
        glVertex2f(1.8,-.3);
        glVertex2f(1.77,-.35);
        glVertex2f(1.8,-.3);
        glVertex2f(1.83,-0.35);
      
        glEnd();
   
   
   
    //person 
  glBegin(GL_POINTS);
        glPointSize(15);
        glColor3f(0, 0.0,0); //black
    glVertex3f(1.8, 0.32f, 0.0f);
        glEnd();
 glBegin(GL_LINES);
        glColor3f(0.0, 0.0,0.0); 
        glVertex2f(1.8,0.3); 
        glVertex2f(1.8,0.2);
        glEnd();
         glBegin(GL_LINES);
        glColor3f(0.0, 0.0,0.0); 
         glVertex2f(1.8,0.25);
       glVertex2f(1.77,.22);
       glVertex2f(1.8,0.25);
       glVertex2f(1.83,.22);
       
         glVertex2f(1.8,0.3);
        glVertex2f(1.77,.28);
         glVertex2f(1.8,0.3);
        glVertex2f(1.83,0.28);
      
        glEnd();
   
//person 
  glBegin(GL_POINTS);
        glPointSize(15);
        glColor3f(0, 0.0,0); //black
    glVertex3f(1.8, 0.6f, 0.0f);
        glEnd();
 glBegin(GL_LINES);
        glColor3f(0.0, 0.0,0.0);  
        glVertex2f(1.8,0.6);
       glVertex2f(1.8, 0.5);
        glEnd();
         glBegin(GL_LINES);
        glColor3f(0.0, 0.0,0.0); 
         glVertex2f(1.8,0.55);
       glVertex2f(1.77,.53);
       glVertex2f(1.8,0.55);
       glVertex2f(1.83,.53);
       
        glVertex2f(1.8,.5);
        glVertex2f(1.77,.45);
        glVertex2f(1.8,.5);
        glVertex2f(1.83,.45);
      
        glEnd();



    glutSwapBuffers(); // Double buffered - swap the front and back buffers

    // Change the rotational angle after each display()
    angle += 0.3f;
        angle2 += 0.2f;
}



/* Handler for window re-size event. Called back when the window first appears and
   whenever the window is re-sized with its new width and height */
void reshape(GLsizei width, GLsizei height) { // GLsizei for non-negative integer
    // Compute aspect ratio of the new window
    if (height == 0) height = 1; // To prevent divide by 0
    GLfloat aspect = (GLfloat) width / (GLfloat) height;

    // Set the viewport to cover the new window
    glViewport(0, 0, width, height);

    // Set the aspect ratio of the clipping area to match the viewport
    glMatrixMode(GL_PROJECTION); // To operate on the Projection matrix
    glLoadIdentity();
    if (width >= height) {
        // aspect >= 1, set the height from -1 to 1, with larger width
        gluOrtho2D(-1.0 * aspect, 1.0 * aspect, -1.0, 1.0);
    } else {
        // aspect < 1, set the width to -1 to 1, with larger height
        gluOrtho2D(-1.0, 1.0, -1.0 / aspect, 1.0 / aspect);
    }
}


/* Main function: GLUT runs as a console application starting at main() */
int main(int argc, char ** argv) {
    glutInit( & argc, argv); // Initialize GLUT
    glutInitDisplayMode(GLUT_DOUBLE); // Enable double buffered mode
    glutInitWindowSize(640, 480); // Set the window's initial width & height - non-square
    glutInitWindowPosition(50,50);// Position the window's initial top-left corner
    glutCreateWindow("************************ Chocolate ************************"); // Create window with the given title
    glutDisplayFunc(display); // Register callback handler for window re-paint event
    glutReshapeFunc(reshape); // Register callback handler for window re-size event
    glutIdleFunc(idle); // Register callback handler if no other event


  glutTimerFunc(0,timer,0);
   glutTimerFunc(0,timer2,0);
   glutTimerFunc(0,timer3,0);
   glutTimerFunc(0,timer4,0);
   // glutTimerFunc(0,timer5,0);
 
    initGL(); // Our own OpenGL initialization
    glutMainLoop(); // Enter the infinite event-processing loop
    return 0;
}


			
void timer2(){
	
	glutPostRedisplay();
	glutTimerFunc(1000/60,timer2,0);
			
switch(flag){
	case 1: 
		if (x_position <-.4)
			x_position += 0.015;
		else
			flag = -1;
		break;
	case -1:
		if (x_position>-1.0)
			x_position -= 0.005;
		else
			flag = 1;
		break;
	}
	
	


}
			
void timer(){
	
	glutPostRedisplay();
	glutTimerFunc(1000/60,timer,0);
			
switch(flag){
	case 1: 
		if (x_position <-.4)
			x_position += 0.015;
		else
			flag = -1;
		break;
	case -1:
		if (x_position>-1.0)
			x_position -= 0.005;
		else
			flag = 1;
		break;
	}
	
	


}			
void timer3(){
	
	glutPostRedisplay();
	glutTimerFunc(1000/60,timer3,0);
			
switch(state){
	case 1: 
		if (x_position2 <-.06)
			x_position2 += 0.015;
		else
			state= -1;
		break;
	case -1:
		if (x_position2>-.16)
			x_position2 -= 0.005;
		else
			state = 1;
		break;
	}
	


}

void timer4(){
	
	glutPostRedisplay();
	glutTimerFunc(1000/60,timer4,0);

switch(state1){
	case 1: 
		if (x_position4 >.8)
			x_position4-= 0.005;
		else
			state1=-1;
		break;
	case -1:
		if (x_position4  < 0.9)
			x_position4 += 0.005;
		else
			state1 = 1;
		break;
	}


}

